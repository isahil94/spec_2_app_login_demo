# Requirements Specification

## Scope
Build a secure, responsive web-based Task Management System for teams, aligned to the provided Figma reference.

## Primary Actors
- Guest user
- Authenticated team member
- Task assignee

## Functional Requirements

### Authentication
- FR-001: The system shall allow new users to register with required account details.
- FR-002: The system shall allow existing users to log in using valid credentials.
- FR-003: The system shall deny access to protected pages when the user is not authenticated.

### Dashboard
- FR-004: The system shall display a dashboard after successful login.
- FR-005: The dashboard shall summarize the user’s tasks by status.
- FR-006: The dashboard shall provide quick navigation to task management actions.

### Task Management
- FR-007: The system shall allow authenticated users to create a task.
- FR-008: The system shall allow task edits.
- FR-009: The system shall allow task deletion.
- FR-010: The system shall require a task title and status when creating or updating a task.

### Team Assignment
- FR-011: The system shall allow assigning a task to a team member.
- FR-012: The system shall display the current assignee for each task.

### Task Status Tracking
- FR-013: The system shall support task statuses for lifecycle tracking.
- FR-014: The system shall allow updating status as work progresses.

### Search and Filtering
- FR-015: The system shall support searching tasks.
- FR-016: The system shall support filtering tasks by status.
- FR-017: Search and filters shall be combinable on the task listing view.

## Business Rules
- BR-001: Only authenticated users may create, edit, delete, assign, search, and filter tasks.
- BR-002: A task must always have exactly one active status value.
- BR-003: Task assignment must reference a valid existing team member.
- BR-004: Deleted tasks are removed from active task listings.
- BR-005: Dashboard metrics must reflect the latest saved task state.

## Data Requirements
- Task: id, title, description (optional), status, assignee (optional), created_at, updated_at.
- User: id, name, email/username, authentication credential.
- Status set baseline: To Do, In Progress, Done.

## Constraints and Clarifications
- The provided specification does not define advanced roles (admin/manager), so default permissions are team-member level.
- The provided specification does not define pagination, export, reminders, comments, or labels in scope.
- The Figma link is treated as UI behavior and visual reference; business requirements remain implementation-agnostic.
