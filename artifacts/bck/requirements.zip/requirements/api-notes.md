# API Notes

## Suggested Endpoints
- POST /auth/register
- POST /auth/login
- POST /auth/logout
- GET /tasks
- POST /tasks
- PATCH /tasks/{id}
- DELETE /tasks/{id}
- GET /users

## Suggested Payloads
- Task create/update payload should include title, description, assigneeId, status
- Authentication should use secure token-based session handling

## Notes
- API responses should support both list and detail views for tasks.
- Validation errors should be structured and returned consistently.
