# Traceability Matrix

| Requirement | User Story | Screen | API Notes |
|---|---|---|---|
| FR-001 Registration | US-001 | Registration screen | POST /auth/register |
| FR-002 Sign In | US-002 | Login screen | POST /auth/login |
| FR-003 Dashboard | US-003 | Dashboard | GET /tasks |
| FR-004 Task CRUD | US-004, US-005, US-006 | Task form/modal | POST/PATCH/DELETE /tasks |
| FR-005 Assignment | US-007 | Task form/modal | PATCH /tasks/{id} |
| FR-006 Status Tracking | US-008 | Dashboard/task details | PATCH /tasks/{id} |
| FR-007 Search and Filter | US-009 | Dashboard | GET /tasks |
| FR-008 Responsive UI | US-010 | All screens | N/A |
