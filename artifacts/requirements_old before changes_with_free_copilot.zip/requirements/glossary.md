# Glossary

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-02
- Status: Draft
- Workflow ID: task-management-ba

## Business Terms
| Term | Definition |
|---|---|
| Task | A discrete unit of work that can be created, assigned, tracked, and completed. |
| Owner | The user or team responsible for governing a task. |
| Assignee | The user responsible for progressing a task. |
| Reporter | The user who created or reported a task. |
| Archived Task | A task that remains searchable but is read-only and no longer active. |
| Dashboard | The main workspace summary for workload, progress, and deadlines. |
| Team Lead | A role responsible for overseeing team work and assignments. |
| Team Member | A role that participates in work and manages assigned tasks. |
| Administrator | A role responsible for system-wide configuration and oversight. |

## Acronyms
| Acronym | Expansion |
|---|---|
| JWT | JSON Web Token |
| OAuth | Open Authorization |
| UI | User Interface |

## Domain Definitions
- Notification: A business alert related to task assignments, updates, mentions, or deadlines.
- Report: A business view of task, team, and user performance information.
