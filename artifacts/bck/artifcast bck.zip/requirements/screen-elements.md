# Screen Elements (Business View)

## Dashboard
- Task summary cards
- Task status overview area
- Search input
- Filter controls
- Task list section

## Task Management View
- Create task action
- Edit task action
- Delete task action
- Assignment selector
- Status selector

## Authentication Views
- Registration form fields
- Login form fields
- Password reset entry points

Note: Element descriptions are business-facing and derived from stated requirements and provided design reference intent.
