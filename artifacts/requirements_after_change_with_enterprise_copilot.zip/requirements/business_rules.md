# Business Rules Template

## Purpose
Capture canonical business rules in a compact, traceable format without introducing implementation detail.

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03
- Status: Draft
- Workflow ID: task-management-ba

## Business Rules

### Rule ID: BR-001
- Rule Name: Single Task Ownership
- Description: Every task must have exactly one owner and may have at most one assignee.
- Business Justification: Preserves accountability and avoids assignment ambiguity.
- Applies To: Task creation and update flows.
- Validation: Create/update blocked if owner missing or multiple assignees attempted.
- Exception: None.
- Priority: Critical
- Related Stories: US-005, US-006

### Rule ID: BR-002
- Rule Name: Permanent Deletion Restriction
- Description: Only Administrator may permanently delete tasks.
- Business Justification: Prevents irreversible loss by non-governance roles.
- Applies To: Delete and bulk delete actions.
- Validation: Non-admin permanent delete requests are denied.
- Exception: None.
- Priority: Critical
- Related Stories: US-008, US-011

### Rule ID: BR-003
- Rule Name: Archived Visibility
- Description: Archived tasks remain searchable and read-only until restored by an authorized actor.
- Business Justification: Maintains historical visibility with integrity.
- Applies To: Task list, task detail, search.
- Validation: Archived tasks shown in search and blocked from standard edits.
- Exception: Restore action by permitted role.
- Priority: High
- Related Stories: US-007, US-008

### Rule ID: BR-004
- Rule Name: Role-Bound Archive and Restore
- Description: Standard users may archive own tasks; restore follows role permission matrix.
- Business Justification: Balances operational flexibility and governance.
- Applies To: Task lifecycle controls.
- Validation: Ownership and role checks required for archive/restore actions.
- Exception: Administrator override according to permissions matrix.
- Priority: High
- Related Stories: US-006, US-008

### Rule ID: BR-005
- Rule Name: Status Transition Policy
- Description: Allowed transitions are Todo->In Progress, In Progress->Review, Review->Completed, Review->In Progress, Blocked->In Progress.
- Business Justification: Enforces consistent workflow progression.
- Applies To: Task status updates.
- Validation: Requests outside policy are rejected and prior status retained.
- Exception: None.
- Priority: Critical
- Related Stories: US-006

### Rule ID: BR-006
- Rule Name: Immutable Task History
- Description: Task activity history cannot be altered once recorded.
- Business Justification: Provides trustworthy operational evidence.
- Applies To: Task history timeline.
- Validation: History entries are append-only.
- Exception: None.
- Priority: Critical
- Related Stories: US-006, US-009

### Rule ID: BR-007
- Rule Name: Mandatory Audit on Updates
- Description: Every update to task or governance entities must record audit information.
- Business Justification: Supports compliance, traceability, and review.
- Applies To: Task updates, user management, team management, report access.
- Validation: Update completion requires audit event confirmation.
- Exception: None.
- Priority: Critical
- Related Stories: US-004, US-006, US-008, US-009, US-011, US-012

### Rule ID: BR-008
- Rule Name: Due Date Validity
- Description: Due date cannot be earlier than current date at save time.
- Business Justification: Prevents invalid planning and deadline semantics.
- Applies To: Task create/edit.
- Validation: Save rejected for past due date.
- Exception: None.
- Priority: High
- Related Stories: US-005, US-006

### Rule ID: BR-009
- Rule Name: Completed Task Edit Restriction
- Description: Completed tasks are read-only for non-admin roles.
- Business Justification: Protects completion integrity and reporting accuracy.
- Applies To: Task edit actions.
- Validation: Non-admin update attempts on completed task are denied.
- Exception: Administrator may edit.
- Priority: High
- Related Stories: US-006

### Rule ID: BR-010
- Rule Name: Credential and Identity Validation
- Description: Authentication and profile credentials must satisfy defined email and password validation constraints.
- Business Justification: Protects account integrity and access control.
- Applies To: Register, login, reset password, profile updates.
- Validation: Invalid credential inputs are rejected with feedback.
- Exception: None.
- Priority: Critical
- Related Stories: US-001, US-002, US-003, US-010

### Rule ID: BR-011
- Rule Name: Role Matrix Enforcement
- Description: Feature access and visibility must follow Administrator, Team Lead, and Team Member permission matrix.
- Business Justification: Ensures deterministic authorization across capabilities.
- Applies To: All protected screens and actions.
- Validation: Unauthorized actions denied and controls hidden/disabled.
- Exception: None.
- Priority: Critical
- Related Stories: US-011, US-012

## Notes
- Keep rules business-oriented and testable.
- Avoid implementation, API, or database design detail.