# API Notes

Deprecated for Business Analyst stage.

This artifact is intentionally not used.
Refer to business-capability-requirements.md for business capability scope.
