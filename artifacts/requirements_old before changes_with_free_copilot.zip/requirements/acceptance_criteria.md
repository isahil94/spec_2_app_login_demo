# Acceptance Criteria

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-02
- Status: Draft
- Artifact ID: AC-001
- Traceability: US-001–US-008, REQ-001–REQ-013

## Acceptance Criteria by User Story

### US-001 — Authentication and Account Access
- AC-001: A user can successfully register with a valid email and password and reach the authenticated experience.
- AC-002: A user can sign in with valid credentials and be redirected to the appropriate workspace.
- AC-003: A user can recover access through a password recovery flow and receive a clear success or failure message.
- AC-004: Invalid credentials or invalid password formats produce a clear validation or error message.
- AC-005: A user can update profile details, password, and avatar within the allowed permissions.

---

### US-002 — Task Lifecycle Management
- AC-006: A user can create a task with a required title, valid status, priority, and due date.
- AC-007: A user can view, edit, archive, restore, duplicate, or delete a task according to their role and task state.
- AC-008: A completed task cannot be edited by a standard user, and an archived task is read-only.
- AC-009: A task record preserves ownership, assignment, and update history after each change.
- AC-010: Invalid task values produce a clear validation message and prevent saving.

---

### US-003 — Task Collaboration
- AC-011: A user can add a comment to a task and see it appear in the task activity history.
- AC-012: A user can attach supporting content to a task and see it linked to the task record.
- AC-013: A user without task access cannot view or add collaborative content for that task.
- AC-014: A task update creates an auditable activity entry that reflects the change.

---

### US-004 — Search, Filter, and Sort
- AC-015: A user can search tasks by title, description, or label and view matching results.
- AC-016: A user can filter tasks by status, priority, assignee, due date, created date, or team.
- AC-017: A user can sort tasks by due date, priority, status, or recency.
- AC-018: A search with no matches shows an empty-state message and no unauthorized results.

---

### US-005 — User and Team Administration
- AC-019: An administrator can invite, disable, delete, or reset a user account.
- AC-020: An administrator can assign roles and manage team memberships.
- AC-021: A non-administrator cannot access administrative functions.
- AC-022: Administrative changes are visible in the relevant user or team views and are auditable.

---

### US-006 — Notifications and Reminders
- AC-023: A user receives a notification when assigned to a task, mentioned, or involved in a relevant update.
- AC-024: A user can configure notification channels and preferences for their account.
- AC-025: A user receives a notification for approaching or overdue deadlines when the event is relevant.
- AC-026: Notification delivery respects the user’s permissions and preferences.

---

### US-007 — Reporting and Oversight
- AC-027: An authorized user can open a productivity, completion, overdue, or workload report.
- AC-028: A report reflects current data within the user’s authorized scope and selected filters.
- AC-029: A report with no data shows a clear empty-state message.
- AC-030: An unauthorized user cannot access reports outside their scope.

---

### US-008 — Preferences and Settings
- AC-031: A user can update account settings such as theme, notifications, language, timezone, privacy, and preferences.
- AC-032: An administrator can manage organization defaults and system-level settings where permitted.
- AC-033: Invalid or unsupported settings values are rejected with a clear error message.
- AC-034: Settings changes are persisted for the correct account or organizational scope.

## Coverage Expectations
- Each story includes happy path, alternate path, validation, error handling, authorization, and audit expectations where applicable.
- Each acceptance criterion is measurable and testable.
