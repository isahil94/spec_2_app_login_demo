# Screen Elements

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03

### Screen Name: Login
- Purpose: Authenticate users into the system

| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Email | Input | Email | user@example.com | Yes | Valid email format | None | Visible to all | Enabled when page loaded | N/A | Label associated; aria-required |
| Password | Input | Password | •••••• | Yes | Minimum 8 characters | None | Visible to all | Enabled when page loaded | N/A | Password field has show/hide control |
| Remember Me | Checkbox | Remember Me | None | No | N/A | Unchecked | Visible to all | Enabled | Persists session when checked | Keyboard accessible |
| Login Button | Button | Log in | None | Yes | Disabled until required fields valid | N/A | Visible to all | Disabled until valid | Triggers authentication | Focusable |

### Screen Name: Task List
- Purpose: Browse and manage tasks

| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Search Box | Input | Search tasks | Search by title, description, labels | No | N/A | Empty | Visible to authenticated users | Enabled | N/A | Keyboard accessible |
| Filter Panel | Panel | Filters | N/A | No | N/A | Collapsed by default on small screens | Visible to authenticated users | N/A | N/A | Controls accessible via keyboard |
| Task Row | Read-only Text | Title (and meta) | N/A | Yes (title) | Title max 100 chars | N/A | Visible to users with view permission | Row actions enabled based on permissions | Shows status, assignee, due date | ARIA roles for list items |
