# User Stories

- US-001: As a new user, I want to register, so that I can access team task management.
- US-002: As a user, I want to log in and log out, so that my work access remains secure.
- US-003: As a team member, I want to view a dashboard, so that I can understand task progress quickly.
- US-004: As a team member, I want to create tasks, so that work items are captured clearly.
- US-005: As a team member, I want to edit tasks, so that task details stay accurate.
- US-006: As a team member, I want to delete tasks when no longer needed, so that task lists stay relevant.
- US-007: As a team lead, I want to assign tasks, so that accountability is clear.
- US-008: As a team member, I want to track task status, so that progress is visible.
- US-009: As a user, I want to search tasks, so that I can find work items quickly.
- US-010: As a user, I want to filter tasks, so that I can focus on relevant work.
