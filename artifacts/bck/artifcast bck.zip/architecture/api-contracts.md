# API Contracts

## Metadata
- Version: 1.0
- Author: Solution Architect Agent
- Date: 2026-06-30
- Status: Draft
- API ID: api-task-mgmt-v1
- Service: Task Management API
- Traceability: architecture-design.md, requirements-spec.md, user-stories.md

## API Overview
REST API for authentication, dashboard, and task management. Contracts are versioned under /api/v1 and designed for independent frontend/backend implementation.

## Conventions
- Base Path: /api/v1
- Content Type: application/json
- Authentication: Bearer JWT for protected routes
- Time Format: ISO 8601 UTC
- Pagination: page (>=1), pageSize (1..100), total, items

## Authentication and Authorization
- Public Endpoints: register, login, health
- Protected Endpoints: dashboard and task endpoints
- Authorization Model (provisional):
  - Team Member: CRUD own-visible tasks, update status where authorized
  - Team Lead: assign tasks, view team-level dashboard
  - System Administrator: full management operations
- Note: Role matrix is pending approval from OQ-001.

## Endpoint Summary
- POST /auth/register
- POST /auth/login
- POST /auth/logout
- GET /dashboard/summary
- GET /tasks
- POST /tasks
- GET /tasks/{taskId}
- PATCH /tasks/{taskId}
- DELETE /tasks/{taskId}
- PATCH /tasks/{taskId}/assign
- PATCH /tasks/{taskId}/status
- GET /health

## Schemas

### RegisterRequest
- email: string, required, valid email
- password: string, required, min length 8
- fullName: string, required, 1..120 chars

### LoginRequest
- email: string, required
- password: string, required

### AuthResponse
- accessToken: string
- tokenType: string (Bearer)
- expiresIn: integer seconds
- user: UserSummary

### UserSummary
- id: uuid
- email: string
- fullName: string
- role: enum (TeamMember, TeamLead, Admin)

### TaskCreateRequest
- title: string, required, 1..200 chars
- description: string, optional, max 5000 chars
- assigneeId: uuid, required by assumption OQ-004
- status: enum (Todo, InProgress, Done), required by assumption OQ-002
- dueDate: string(datetime), optional
- priority: enum (Low, Medium, High), optional default Medium
- labels: array of string, optional

### TaskUpdateRequest
- title: string, optional
- description: string, optional
- dueDate: string(datetime), optional nullable
- priority: enum, optional
- labels: array of string, optional

### TaskAssignRequest
- assigneeId: uuid, required

### TaskStatusRequest
- status: enum (Todo, InProgress, Done), required

### TaskResponse
- id: uuid
- title: string
- description: string or null
- status: enum
- assignee: UserSummary
- createdBy: UserSummary
- dueDate: string(datetime) or null
- priority: enum
- labels: array of string
- createdAt: string(datetime)
- updatedAt: string(datetime)

### DashboardSummaryResponse
- totalTasks: integer
- todoCount: integer
- inProgressCount: integer
- doneCount: integer
- overdueCount: integer

### TaskListResponse
- page: integer
- pageSize: integer
- total: integer
- items: array of TaskResponse

## Detailed Endpoints

### POST /auth/register
Purpose: Create account (FR-001)
Request: RegisterRequest
Responses:
- 201: AuthResponse
- 400: ValidationError
- 409: ConflictError (email already exists)

### POST /auth/login
Purpose: Authenticate user (FR-002)
Request: LoginRequest
Responses:
- 200: AuthResponse
- 401: AuthenticationError

### POST /auth/logout
Purpose: Invalidate session token (FR-002)
Responses:
- 204: No Content
- 401: AuthenticationError

### GET /dashboard/summary
Purpose: Dashboard KPI summary (FR-003)
Query:
- teamId: uuid, optional
- from: datetime, optional
- to: datetime, optional
Responses:
- 200: DashboardSummaryResponse
- 401: AuthenticationError
- 403: AuthorizationError

### GET /tasks
Purpose: List/search/filter tasks (FR-009, FR-010)
Query:
- q: string, optional
- status: enum, optional
- assigneeId: uuid, optional
- createdBy: uuid, optional
- dueBefore: datetime, optional
- dueAfter: datetime, optional
- priority: enum, optional
- label: string, optional
- sortBy: enum(createdAt, dueDate, priority, status), optional
- sortOrder: enum(asc, desc), optional
- page: int, optional default 1
- pageSize: int, optional default 20
Responses:
- 200: TaskListResponse
- 401: AuthenticationError

### POST /tasks
Purpose: Create task (FR-004)
Request: TaskCreateRequest
Responses:
- 201: TaskResponse
- 400: ValidationError
- 401: AuthenticationError
- 403: AuthorizationError

### GET /tasks/{taskId}
Purpose: Retrieve task details
Responses:
- 200: TaskResponse
- 401: AuthenticationError
- 403: AuthorizationError
- 404: NotFoundError

### PATCH /tasks/{taskId}
Purpose: Edit task (FR-005)
Request: TaskUpdateRequest
Responses:
- 200: TaskResponse
- 400: ValidationError
- 401: AuthenticationError
- 403: AuthorizationError
- 404: NotFoundError

### DELETE /tasks/{taskId}
Purpose: Delete task (FR-006)
Responses:
- 204: No Content
- 401: AuthenticationError
- 403: AuthorizationError
- 404: NotFoundError

### PATCH /tasks/{taskId}/assign
Purpose: Assign task (FR-007)
Request: TaskAssignRequest
Responses:
- 200: TaskResponse
- 400: ValidationError
- 401: AuthenticationError
- 403: AuthorizationError
- 404: NotFoundError

### PATCH /tasks/{taskId}/status
Purpose: Update task status (FR-008)
Request: TaskStatusRequest
Responses:
- 200: TaskResponse
- 400: ValidationError
- 401: AuthenticationError
- 403: AuthorizationError
- 404: NotFoundError

### GET /health
Purpose: Liveness and readiness signal
Responses:
- 200: { status: "ok" }

## Error Model
All errors return:
- code: string
- message: string
- details: object or null
- traceId: string

Error Codes:
- AUTH_001: Invalid credentials
- AUTH_002: Token expired or invalid
- AUTHZ_001: Insufficient permissions
- TASK_001: Task not found
- TASK_002: Invalid task status transition
- VALID_001: Request validation failed
- CONFLICT_001: Resource conflict
- SYS_001: Internal server error

## Validation Rules
- Email must be unique and valid format.
- Password length >= 8.
- Task title cannot be empty.
- Task status transitions must follow approved lifecycle.
- pageSize must not exceed 100.
- Assignment target user must exist and be active.

## Versioning and Compatibility
- URL versioning: /api/v1
- Backward-compatible additions allowed in minor revisions.
- Breaking changes require /api/v2 and migration notes.

## Dependencies
- Auth token provider and key management.
- Relational persistence for user and task entities.
- Time synchronization for due-date and overdue calculations.

## Open Questions
### OQ-001
Category: Security
Question: Final role-permission matrix for V1.
Impact: High
Blocking: Yes
Approval Required: Yes
Target Stage: Solution Architecture

### OQ-002
Category: Functional
Question: Final status lifecycle values and transition rules.
Default Assumption: Todo -> InProgress -> Done
Impact: High
Blocking: No
Approval Required: No
Target Stage: Backend

## Open Question Summary
- Total Questions: 2
- Blocking Questions: 1
- Approval Requests Required: 1
- Workflow Status: REQUIRES HUMAN APPROVAL
- Next Agent: Supervisor Approval Path

## Approval
- Prepared By: Solution Architect Agent
- Reviewed By: Pending
- Approved By: Pending
