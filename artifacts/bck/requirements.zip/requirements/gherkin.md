# Gherkin Scenarios

## Scenario: User registers successfully
Given a new user opens the registration page
When they submit valid registration details
Then an account is created and they can sign in

## Scenario: User signs in with invalid credentials
Given a user is on the login page
When they submit invalid credentials
Then access is denied and an error is shown

## Scenario: User creates a task
Given a signed-in user is on the dashboard
When they create a new task
Then the task is added to the visible task list

## Scenario: User filters tasks
Given multiple tasks exist
When the user filters by status or assignee
Then only matching tasks remain visible
