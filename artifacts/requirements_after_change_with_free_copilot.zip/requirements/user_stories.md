# User Stories

## Metadata
- Version: 1.1
- Author: Business Analyst Agent
- Date: 2026-07-03
- Status: Draft
- Workflow ID: WF-20260703-BA01

## Stories

### US-001
- Epic: EPIC-001
- Feature: FEAT-001 (Task CRUD & lifecycle)
- Story Statement: As a Team Member, I want to create a task so that I can track personal work.
- Preconditions: Authenticated session
- Trigger: User selects Create Task
- Primary Flow: User opens Create Task -> supplies Title, optional Description, Priority, Due Date -> saves -> Task created with ID and audit record
- Business Validation: Title required (<=100 chars); Due Date >= today
- Priority: Must Have

### US-002
- Epic: EPIC-001
- Feature: FEAT-001 (Task Edit)
- Story Statement: As a Task Owner, I want to update my task so that task details remain current.
- Preconditions: Authenticated session; user is owner or has permission
- Alternate Flow: If task is Completed and user is not Administrator, edit denied

### US-003
- Epic: EPIC-001
- Feature: FEAT-002 (Search & Filter)
- Story Statement: As a Team Lead, I want to search and filter tasks so that I can find and prioritize work.
- Preconditions: Authenticated session
- Primary Flow: User enters search keywords and applies filters -> results returned and sortable

### US-004
- Epic: EPIC-002
- Feature: FEAT-005 (Teams & Roles)
- Story Statement: As an Administrator, I want to invite users to teams so that I can build team membership.

### US-005
- Epic: EPIC-003
- Feature: FEAT-006 (Notifications)
- Story Statement: As an Assignee, I want to receive notifications when assigned a task so that I know my responsibilities.

### Traceability
- Each story maps to functional requirements REQ-001..REQ-010 (see `traceability.md`).
