# Database Design

## Metadata
- Version: 1.0
- Author: Solution Architect Agent
- Date: 2026-06-30
- Status: Draft
- Database ID: db-task-mgmt-v1
- Traceability: requirements-spec.md, business-data-model.md, architecture-design.md

## Database Overview
Relational schema for user, team, role, and task management with audit-friendly fields and indexes optimized for search and filtering.

## Entity Relationship Diagram
```mermaid
erDiagram
    TEAM ||--o{ USER : contains
    ROLE ||--o{ USER : assigned_to
    USER ||--o{ TASK : creates
    USER ||--o{ TASK : assigned_to
    TASK ||--o{ TASK_LABEL : has
    LABEL ||--o{ TASK_LABEL : referenced_by

    TEAM {
      uuid id PK
      string name
      timestamp created_at
      timestamp updated_at
    }

    ROLE {
      uuid id PK
      string name
      string description
      timestamp created_at
      timestamp updated_at
    }

    USER {
      uuid id PK
      uuid team_id FK
      uuid role_id FK
      string email UK
      string full_name
      string password_hash
      bool is_active
      timestamp created_at
      timestamp updated_at
    }

    TASK {
      uuid id PK
      uuid created_by FK
      uuid assignee_id FK
      string title
      text description
      string status
      string priority
      timestamp due_date
      timestamp created_at
      timestamp updated_at
      timestamp deleted_at
    }

    LABEL {
      uuid id PK
      string name UK
      timestamp created_at
    }

    TASK_LABEL {
      uuid task_id FK
      uuid label_id FK
    }
```

## Logical Tables

### teams
- id uuid primary key
- name varchar(120) not null
- created_at timestamptz not null default now()
- updated_at timestamptz not null default now()

### roles
- id uuid primary key
- name varchar(50) unique not null
- description varchar(255) null
- created_at timestamptz not null default now()
- updated_at timestamptz not null default now()

### users
- id uuid primary key
- team_id uuid not null references teams(id)
- role_id uuid not null references roles(id)
- email varchar(320) unique not null
- full_name varchar(120) not null
- password_hash varchar(255) not null
- is_active boolean not null default true
- created_at timestamptz not null default now()
- updated_at timestamptz not null default now()

### tasks
- id uuid primary key
- created_by uuid not null references users(id)
- assignee_id uuid not null references users(id)
- title varchar(200) not null
- description text null
- status varchar(30) not null
- priority varchar(20) not null default 'Medium'
- due_date timestamptz null
- created_at timestamptz not null default now()
- updated_at timestamptz not null default now()
- deleted_at timestamptz null

### labels
- id uuid primary key
- name varchar(64) unique not null
- created_at timestamptz not null default now()

### task_labels
- task_id uuid not null references tasks(id) on delete cascade
- label_id uuid not null references labels(id) on delete cascade
- primary key (task_id, label_id)

## Constraints and Business Rules
- tasks.title is required.
- tasks.assignee_id is required (assumption from OQ-004).
- tasks.status allowed values (assumption): Todo, InProgress, Done.
- users.email must be unique and case-insensitive normalized.
- Soft delete for tasks using deleted_at.

## Index Strategy
- idx_tasks_assignee_status_due on tasks(assignee_id, status, due_date)
- idx_tasks_status_created on tasks(status, created_at desc)
- idx_tasks_due_date on tasks(due_date)
- idx_tasks_title_search on tasks using gin(to_tsvector('simple', title || ' ' || coalesce(description, '')))
- idx_users_team_role on users(team_id, role_id)

## Query Patterns Supported
- Task list by assignee/status with pagination.
- Search tasks by free text and filters.
- Dashboard counts by status and overdue state.
- Team-level task visibility via joins on users/team.

## Migration Plan
1. Create foundational tables: teams, roles, users.
2. Create task-related tables: tasks, labels, task_labels.
3. Seed roles (TeamMember, TeamLead, Admin).
4. Add indexes and constraints.
5. Add baseline reference data and run validation checks.

## Backup and Recovery
- Full nightly backups.
- WAL archiving for PITR.
- Monthly restore verification.

## Data Retention and Compliance
- Soft-deleted tasks retained for audit window.
- Authentication-related logs retained per security policy.
- Personal data handling follows least-privilege access.

## Open Questions
### OQ-DB-001
Question: Confirm final mandatory fields for task creation beyond title, assignee, status.
Impact: Medium
Blocking: No
Approval Required: No
Target Stage: Database

### OQ-DB-002
Question: Confirm whether task status lifecycle requires additional states (Blocked, Cancelled).
Impact: Medium
Blocking: No
Approval Required: No
Target Stage: Backend/Database

## Open Question Summary
- Total Questions: 2
- Blocking Questions: 0
- Approval Requests Required: 0
- Workflow Status: NON-BLOCKING QUESTIONS OPEN
- Next Agent: Database Developer

## Approval
- Prepared By: Solution Architect Agent
- Reviewed By: Pending
- Approved By: Pending
