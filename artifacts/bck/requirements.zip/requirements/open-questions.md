# Open Questions

1. Should the initial release support multiple roles such as admin, manager, and member?
2. Which task fields are required at creation time?
3. Should due dates, priorities, and comments be part of v1?
4. What level of search and filtering depth is expected for the first release?
