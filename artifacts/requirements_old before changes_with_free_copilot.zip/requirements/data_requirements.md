# Data Requirements

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-02
- Status: Draft
- Workflow ID: task-management-ba

## Business Entities

### Entity: User
- Business Meaning: Represents an authenticated individual with account, profile, role, preferences, and visibility scope.
- Owner: Business/Administrator
- Required Attributes: Email, password credential, role, account status.
- Optional Attributes: Display name, contact information, avatar, preferences, timezone, language.
- Relationships: Belongs to one or more teams; owns or is assigned to tasks; receives notifications.
- Lifecycle: Active, disabled, deleted, restored where applicable.
- Retention: Account data retained according to business policy.
- PII Classification: Sensitive

### Entity: Team
- Business Meaning: Represents a group of users working together on shared work.
- Owner: Administrator or Team Lead
- Required Attributes: Team name, team lead, membership scope.
- Optional Attributes: Description, ownership, status.
- Relationships: Contains users; owns or is associated with tasks.
- Lifecycle: Active or archived where relevant.
- Retention: Retained while active and for defined historical reporting periods.
- PII Classification: Internal

### Entity: Task
- Business Meaning: Represents a unit of work with business state, ownership, assignment, and collaboration context.
- Owner: Task owner or assigned team
- Required Attributes: Title, status, priority, owner, reporter, due date.
- Optional Attributes: Description, labels, assignee, attachments, comments, activity history, archived flag.
- Relationships: Belongs to a team or user; associated with comments, attachments, notifications, and history.
- Lifecycle: Todo, In Progress, Review, Completed, Blocked, Archived.
- Retention: Retained for business and audit purposes.
- PII Classification: Internal

### Entity: Notification
- Business Meaning: Represents a business event alert for relevant users.
- Owner: System or user-specific workflow
- Required Attributes: Recipient, event type, trigger, delivery channel.
- Optional Attributes: Message content, read state, preference override.
- Relationships: Related to task and user.
- Lifecycle: Pending, delivered, read, dismissed.
- Retention: Retained per notification policy.
- PII Classification: Internal

### Entity: Report
- Business Meaning: Represents a business view of workload, completion, or overdue activity.
- Owner: Authorized user or team lead
- Required Attributes: Scope, report type, date range.
- Optional Attributes: Filters, recipients, generated time.
- Relationships: Derived from tasks and users.
- Lifecycle: Generated, viewed, archived where applicable.
- Retention: Retained according to reporting policy.
- PII Classification: Internal
