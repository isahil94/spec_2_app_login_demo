# Acceptance Criteria Template

## Purpose
Define objective, verifiable conditions required for a story or feature to be accepted.

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03
- Status: Draft
- Artifact ID: AC-SET-001
- Traceability: US-001..US-012 mapped to REQ-001..REQ-020

## Acceptance Criteria by User Story

### US-001
- AC-001: Given a public user enters valid unique email and compliant password, when submitting Register, then the account is created and a success state is shown.
- AC-002: Given invalid email format or password length below minimum, when submitting Register, then registration is blocked and field-level validation is displayed.
- AC-003: Given an already registered email, when submitting Register, then account creation is rejected with duplicate-account feedback.
- AC-004: Dependency-Unavailable Criterion: Given account services are unavailable, when submitting Register, then the Register screen remains active and shows the Account Service Unavailable state.

### US-002
- AC-005: Given valid credentials, when user submits Login, then Dashboard is shown for the authenticated role and protected routes become accessible.
- AC-006: Given invalid credentials or disabled account, when user submits Login, then access is denied and user remains on Login with clear reason.
- AC-007: Given an authenticated user selects Logout, when logout completes, then session ends and protected routes redirect to Login.
- AC-008: Dependency-Unavailable Criterion: Given authentication dependency is unavailable, when user submits Login, then Login screen shows Authentication Dependency Unavailable state and no session is created.

### US-003
- AC-009: Given a registered email, when user requests Forgot Password, then reset initiation feedback is shown.
- AC-010: Given a valid reset context, when user submits a compliant new password, then password reset succeeds and user is directed to Login.
- AC-011: Given invalid or expired reset context, when user attempts reset, then reset is denied with expiry/invalid message.
- AC-012: Dependency-Unavailable Criterion: Given reset dependency is unavailable, when user submits reset request, then Reset Password screen shows Reset Service Unavailable state.

### US-004
- AC-013: Given an authenticated user, when Dashboard loads, then total/completed/pending/overdue/due-today plus activity and workload are displayed for authorized scope.
- AC-014: Given no tasks in scope, when Dashboard loads, then Empty Dashboard state is shown with role-appropriate messaging.
- AC-015: Given insufficient permission for a metric source, when Dashboard loads, then restricted metric block is hidden or shown as Not Authorized.
- AC-016: Dependency-Unavailable Criterion: Given one or more dashboard data dependencies are unavailable, when Dashboard loads, then Dashboard shows Partial Data Unavailable state while preserving available sections.

### US-005
- AC-017: Given valid required task fields, when user submits Create Task, then task is created and Task Details displays saved values.
- AC-018: Given due date earlier than today or missing required fields, when user submits Create Task, then creation is blocked with field-level errors.
- AC-019: Given user lacks create permission, when user attempts create, then Create action is blocked with authorization message.
- AC-020: Dependency-Unavailable Criterion: Given task creation dependency is unavailable, when user submits Create Task, then Create Task screen shows Task Save Unavailable state and preserves entered data.

### US-006
- AC-021: Given an editable task and authorized actor, when updates conform to policy, then task changes are saved and visible in Task Details.
- AC-022: Given an invalid status transition, when actor attempts transition, then change is rejected and prior status remains.
- AC-023: Given task status is Completed and actor is not Administrator, when actor edits task, then edit is blocked with completed-task restriction message.
- AC-024: Dependency-Unavailable Criterion: Given task update dependency is unavailable, when actor submits edit/status change, then Edit Task or Task Details shows Update Dependency Unavailable state and no partial change is committed.

### US-007
- AC-025: Given query text and allowed criteria, when user searches tasks, then list shows matching role-visible tasks by title/description/labels.
- AC-026: Given selected status/priority/assignee/date/team filters and sort option, when applied, then list reflects filtered ordered results accurately.
- AC-027: Given no matches, when criteria are applied, then Task List shows No Results state while retaining criteria.
- AC-028: Dependency-Unavailable Criterion: Given search/filter dependency is unavailable, when criteria are applied, then Task List shows Search Dependency Unavailable state and maintains last stable result state.

### US-008
- AC-029: Given authorized actor archives task, when action succeeds, then task becomes read-only and remains searchable.
- AC-030: Given authorized restore action, when restore succeeds, then task returns to active lifecycle state.
- AC-031: Given non-administrator attempts permanent delete via bulk or single action, when action submitted, then permanent deletion is denied.
- AC-032: Dependency-Unavailable Criterion: Given archive/restore/bulk dependency is unavailable, when actor submits action, then Task List or Task Details shows Bulk Lifecycle Unavailable state with item-level outcome details.

### US-009
- AC-033: Given authorized actor submits comment or attachment, when submission is valid, then collaboration item appears in task timeline.
- AC-034: Given mention or update trigger occurs, when recipient is eligible, then in-app or email notification is generated per preferences.
- AC-035: Given invalid collaboration input or unauthorized actor, when action submitted, then action is rejected with validation/authorization message.
- AC-036: Dependency-Unavailable Criterion: Given notification dependency is unavailable, when trigger occurs, then Notification Center shows Notification Delivery Delayed state and task action remains committed where policy allows.

### US-010
- AC-037: Given authenticated user edits profile/settings with valid values, when submitted, then updates persist and confirmation is shown.
- AC-038: Given invalid email/password or disallowed preference value, when submitted, then update is blocked with field-level feedback.
- AC-039: Given user attempts to modify another user's personal settings, when attempted, then action is denied.
- AC-040: Dependency-Unavailable Criterion: Given profile/settings dependency is unavailable, when user saves changes, then Profile or Settings screen shows Preferences Save Unavailable state and retains unsaved input for retry.

### US-011
- AC-041: Given Administrator initiates invite/disable/delete/reset user action, when input is valid, then user-management state is updated and logged.
- AC-042: Given Team Lead manages team-level assignments, when action within team scope, then change is allowed and reflected.
- AC-043: Given Team Member attempts user/team administrative action, when attempted, then action is denied with role-based message.
- AC-044: Dependency-Unavailable Criterion: Given user/team management dependency is unavailable, when management action is submitted, then Settings screen shows Management Service Unavailable state and no unauthorized partial change occurs.

### US-012
- AC-045: Given authorized role selects report type and period, when report runs, then report data is displayed for permitted scope.
- AC-046: Given no data in selected period, when report runs, then report view shows No Data for Selected Period state.
- AC-047: Given Team Member attempts report access, when attempted, then access is denied.
- AC-048: Dependency-Unavailable Criterion: Given reporting dependency is unavailable, when report requested, then Dashboard report area shows Reporting Dependency Unavailable state.

## Coverage Expectations
- Each story must include acceptance criteria for happy path, alternate path, validation, error, edge, authorization, and state transition behavior where applicable.
- Each criterion must be measurable, testable, and unambiguous.
- Each story must cover, where applicable: validation, success, failure, permissions, navigation, search, filtering, sorting, pagination, error handling, audit events, and security behavior.
- Dependency-Unavailable Criterion (mandatory per story): At least one criterion must state the literal expected behavior when a required backend or data dependency cannot be reached. Must specify exact expected screen/state name, not general phrases like appropriate error message.

## Rules
- This file is the single source of truth for acceptance criteria.
- Do not duplicate story narrative here.
- Keep each AC atomic, measurable, and verifiable.
- Ensure each story's AC set covers success path, validation behavior, and authorization behavior where applicable.
- Ensure AC IDs map back to story IDs and related requirement IDs through traceability.
- Ensure AC set covers failure, empty, loading, and exception behavior where applicable.
- Ensure ACs define expected workflow/state-transition outcomes where applicable.
- Do not include implementation technology or design details.

## Approval
- Prepared By: Business Analyst Agent
- Reviewed By: Pending Supervisor Review
- Approved By: Pending