# User Stories

## US-001: Account Registration
As a new user, I want to register for an account, so that I can access the task management system.

## US-002: Secure Sign In
As a registered user, I want to sign in securely, so that my work stays private and protected.

## US-003: View Dashboard
As a team member, I want to view a dashboard of tasks, so that I can understand my current workload.

## US-004: Create a Task
As a team member, I want to create a task, so that I can record work that needs to be done.

## US-005: Edit a Task
As a team member, I want to edit a task, so that I can update details as work changes.

## US-006: Delete a Task
As an authorized user, I want to delete a task, so that I can remove work that is no longer relevant.

## US-007: Assign a Task
As a team lead, I want to assign tasks to team members, so that ownership is clear.

## US-008: Track Task Status
As a team member, I want to track task status, so that I can see progress at a glance.

## US-009: Search and Filter Tasks
As a user, I want to search and filter tasks, so that I can quickly find relevant work.

## US-010: Responsive Experience
As a user, I want the interface to work well on different screen sizes, so that I can use the system anywhere.
