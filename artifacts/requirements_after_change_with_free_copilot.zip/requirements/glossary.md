# Glossary

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03

## Business Terms
| Term | Definition |
|---|---|
| Task | A unit of work tracked by the system. |
| Assignee | The user responsible for completing the task. |
| Owner | The creator or business owner of the task. |

## Acronyms
| Acronym | Expansion |
|---|---|
| JWT | JSON Web Token |
| NFR | Non-Functional Requirement |
