# Screen Elements Template

## Purpose
Describe every screen and every interactive element using business terminology only. Do not include implementation details, HTML, CSS, or code.

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03
- Workflow ID: task-management-ba
- Status: Draft

## Screens

### Screen Name: Login
- Purpose: Authenticate registered users.
- Component or Section: Authentication Form

#### Elements
Use one table row per user-visible or interactive element. Keep the content business-focused and implementation-agnostic.

| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Email | Input | Email | Enter your email | Yes | VAL-005 | None | Visible to public users | Enabled unless submit in progress | BR-010 | Label announced and input focus visible |
| Password | Input | Password | Enter your password | Yes | VAL-006 | None | Visible to public users | Enabled unless submit in progress | BR-010 | Obscured entry with accessible label |
| Remember Me | Checkbox | Remember Me | None | No | Not applicable | Unchecked | Visible to public users | Enabled unless submit in progress | BR-010 | Keyboard operable |
| Login Button | Button | Log In | None | Not applicable | Requires valid required fields | None | Visible to public users | Disabled when required fields invalid | BR-010 | Action name read clearly |
| Forgot Password Link | Link | Forgot Password | None | Not applicable | Not applicable | None | Visible to public users | Enabled always | BR-010 | Link text perceivable |
| Register Link | Link | Create Account | None | Not applicable | Not applicable | None | Visible to public users | Enabled always | BR-010 | Link focus indicator visible |

### Screen Name: Register
- Purpose: Create a new account.
- Component or Section: Registration Form

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Email | Input | Email | Enter email | Yes | VAL-005 | None | Public users only | Disabled while submit in progress | BR-010 | Error text associated to field |
| Password | Input | Password | Create password | Yes | VAL-006 | None | Public users only | Disabled while submit in progress | BR-010 | Password rules announced |
| Register Button | Button | Register | None | Not applicable | Requires valid required fields | None | Public users only | Disabled if fields invalid | BR-010 | Button role and state announced |
| Login Link | Link | Back to Login | None | Not applicable | Not applicable | None | Public users only | Enabled always | BR-010 | Keyboard reachable |

### Screen Name: Dashboard
- Purpose: Display role-scoped operational summary.
- Component or Section: KPI and Activity Panels

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Total Tasks Card | Read-only Text | Total Tasks | None | No | Not applicable | 0 if empty | Authenticated users | Enabled | BR-011 | Readable text contrast |
| Completed Tasks Card | Read-only Text | Completed | None | No | Not applicable | 0 if empty | Authenticated users | Enabled | BR-011 | Readable text contrast |
| Pending Tasks Card | Read-only Text | Pending | None | No | Not applicable | 0 if empty | Authenticated users | Enabled | BR-011 | Readable text contrast |
| Overdue Tasks Card | Read-only Text | Overdue | None | No | Not applicable | 0 if empty | Authenticated users | Enabled | BR-011 | Readable text contrast |
| Due Today Card | Read-only Text | Due Today | None | No | Not applicable | 0 if empty | Authenticated users | Enabled | BR-011 | Readable text contrast |
| Reports Panel | Link | Reports | None | No | Not applicable | None | Admin and Team Lead only | Disabled/Hidden for Team Member | BR-011 | Role-hidden content not focusable |

### Screen Name: Task List
- Purpose: Search, filter, sort, and manage tasks.
- Component or Section: Task Discovery and Actions

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Search Input | Input | Search Tasks | Search by title, description, labels | No | Allowed criteria only | Empty | Authenticated users | Enabled unless dependency unavailable | BR-003 | Search field has clear label |
| Status Filter | Select | Status | Select status | No | Allowed status values only | All | Authenticated users | Enabled | BR-005 | Select options announced |
| Priority Filter | Select | Priority | Select priority | No | Allowed priority values only | All | Authenticated users | Enabled | BR-011 | Select options announced |
| Assignee Filter | Select | Assignee | Select assignee | No | Valid visible assignees | All | Authenticated users | Enabled | BR-011 | Keyboard operable |
| Due Date Filter | Date | Due Date | Select due date | No | Valid date format | None | Authenticated users | Enabled | BR-008 | Date input accessible |
| Team Filter | Select | Team | Select team | No | Valid visible teams | All | Authenticated users | Enabled | BR-011 | Keyboard operable |
| Sort Control | Select | Sort By | Select order | No | Allowed sort fields only | Recently Updated | Authenticated users | Enabled | BR-011 | Keyboard operable |
| Bulk Update Button | Button | Bulk Update | None | Not applicable | Requires one or more tasks selected | None | Role per matrix | Disabled without selected tasks | BR-011 | Selection count announced |
| Bulk Delete Button | Button | Bulk Delete | None | Not applicable | Admin-only permanent delete | None | Administrator only | Hidden/disabled for non-admin | BR-002 | Hidden action not focusable |
| Open Task Link | Link | View Task | None | Not applicable | Not applicable | None | Role-visible tasks only | Enabled for visible tasks | BR-011 | Link text descriptive |

### Screen Name: Task Details
- Purpose: View task context and perform allowed actions.
- Component or Section: Task Overview and Collaboration

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Status Selector | Select | Status | Select status | Yes | BR-005 transition rules | Current status | Roles with edit permission | Disabled if task archived or unauthorized | BR-005, BR-009 | State change feedback announced |
| Edit Task Button | Button | Edit Task | None | Not applicable | Edit permission and state checks | None | Roles with edit rights | Disabled for non-admin on Completed | BR-009 | Disabled state announced |
| Archive Button | Button | Archive | None | Not applicable | Ownership/role checks | None | Permitted roles | Disabled if already archived | BR-004 | Action confirmation announced |
| Restore Button | Button | Restore | None | Not applicable | Role-based restore checks | None | Permitted roles on archived task | Disabled if not archived | BR-004 | Action confirmation announced |
| Comment Input | Input | Add Comment | Write a comment | Yes | Non-empty comment text | Empty | Authorized viewers | Disabled when unavailable | BR-006, BR-007 | Error and success message announced |
| Attachment Upload | Button | Upload Attachment | None | No | Valid attachment policy | None | Authorized viewers | Disabled when unavailable | BR-006, BR-007 | Upload status announced |
| Activity History Panel | Read-only Text | Activity History | None | No | Immutable display only | Existing history | Authorized viewers | Enabled | BR-006 | Chronological order perceivable |

### Screen Name: Create Task
- Purpose: Enter new task details.
- Component or Section: Task Creation Form

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Title | Input | Title | Enter task title | Yes | VAL-001 | Empty | Roles with create permission | Enabled | BR-001 | Required indicator announced |
| Description | Input | Description | Describe task | No | VAL-002 | Empty | Roles with create permission | Enabled | BR-001 | Text area label announced |
| Status | Select | Status | Select status | Yes | VAL-004 | Todo | Roles with create permission | Enabled | BR-005 | Select options announced |
| Priority | Select | Priority | Select priority | Yes | VAL-004 | Medium | Roles with create permission | Enabled | BR-011 | Select options announced |
| Assignee | Select | Assignee | Select assignee | No | Single assignee only | None | Roles with create permission | Enabled | BR-001 | Keyboard operable |
| Due Date | Date | Due Date | Select due date | Yes | VAL-003 | None | Roles with create permission | Enabled | BR-008 | Date picker accessible |
| Labels | Input | Labels | Add labels | No | Not applicable | Empty | Roles with create permission | Enabled | BR-011 | Input label announced |
| Create Button | Button | Create Task | None | Not applicable | Requires valid required fields | None | Roles with create permission | Disabled if validation fails | BR-001, BR-008 | Submit status announced |

### Screen Name: Edit Task
- Purpose: Modify existing task information under policy.
- Component or Section: Task Edit Form

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Editable Fields Group | Input | Task Fields | Existing values | Yes/No by field | VAL-001..VAL-004 | Current values | Authorized users only | Disabled when edit restricted | BR-005, BR-009 | Validation feedback announced |
| Save Changes Button | Button | Save Changes | None | Not applicable | Requires valid updates | None | Authorized users only | Disabled when invalid or unauthorized | BR-009 | Disabled state and error text clear |
| Cancel Button | Button | Cancel | None | Not applicable | Not applicable | None | Authorized users only | Enabled | BR-011 | Keyboard operable |

### Screen Name: Profile
- Purpose: Manage own account details.
- Component or Section: Profile Information

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Avatar Upload | Button | Upload Avatar | None | No | Valid file policy | Existing avatar | Authenticated user own profile | Enabled | BR-010 | Upload status announced |
| Contact Email | Input | Email | Enter contact email | Yes when changed | VAL-005 | Existing email | Own profile only | Enabled | BR-010 | Field association clear |
| Change Password | Input | New Password | Enter new password | Yes when changed | VAL-006 | Empty | Own profile only | Enabled | BR-010 | Password rule description available |
| Save Profile Button | Button | Save Profile | None | Not applicable | Valid changed fields required | None | Own profile only | Disabled if invalid | BR-010 | Save result announced |

### Screen Name: Settings
- Purpose: Manage personal preferences and admin settings.
- Component or Section: Preferences and Governance

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Theme Selector | Select | Theme | Select theme | Yes | Allowed values only | System | Authenticated users | Enabled | BR-010 | Choice state announced |
| Notification Preferences | Toggle | Notifications | None | No | Allowed values only | Enabled | Authenticated users | Enabled | BR-010 | Toggle state announced |
| Language Selector | Select | Language | Select language | No | Allowed values only | Default language | Authenticated users | Enabled | BR-010 | Keyboard operable |
| Time Zone Selector | Select | Time Zone | Select time zone | No | Allowed values only | Account default | Authenticated users | Enabled | BR-010 | Keyboard operable |
| Privacy Preferences | Toggle | Privacy | None | No | Allowed values only | Account default | Authenticated users | Enabled | BR-010 | Toggle state announced |
| Organization Settings Panel | Tab | Organization Settings | None | Not applicable | Admin-only access | Not applicable | Administrator only | Disabled/hidden for non-admin | BR-011 | Hidden content not focusable |
| User Defaults Panel | Tab | User Defaults | None | Not applicable | Admin-only access | Not applicable | Administrator only | Disabled/hidden for non-admin | BR-011 | Hidden content not focusable |
| System Configuration Panel | Tab | System Configuration | None | Not applicable | Admin-only access | Not applicable | Administrator only | Disabled/hidden for non-admin | BR-011 | Hidden content not focusable |
| Save Settings Button | Button | Save Settings | None | Not applicable | Valid selected values | None | Authenticated users; admin sections by role | Disabled if invalid input exists | BR-010, BR-011 | Save result announced |

## Notes
- Keep content business-focused and implementation-agnostic.
- Capture every interactive element that affects user decisions or business outcomes.
- If an element is not applicable, record Not applicable rather than omitting it.
- Do not duplicate the screen-level experience notes from the UI observations artifact; this file is the detailed element inventory.