# Business Rules

- BR-001: Only authenticated users shall access task management features.
- BR-002: A task shall have one accountable assignee at any point in time unless approved otherwise.
- BR-003: Task status changes shall follow the approved lifecycle.
- BR-004: Users shall be able to retrieve task information using search and filter criteria.
- BR-005: Dashboard summaries shall reflect current task state.
- BR-006: Business terminology shall remain consistent across requirements and user-facing labels.
