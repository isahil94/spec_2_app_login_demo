# User Stories

## Epic E1: Account Access
- US-001: As a guest user, I want to register an account so that I can access team task features.
- US-002: As a registered user, I want to log in so that I can access my dashboard and tasks.

## Epic E2: Dashboard Visibility
- US-003: As an authenticated user, I want to see a dashboard summary so that I can quickly understand my workload.

## Epic E3: Task Lifecycle Management
- US-004: As an authenticated user, I want to create tasks so that work can be tracked.
- US-005: As an authenticated user, I want to edit tasks so that task details remain current.
- US-006: As an authenticated user, I want to delete tasks so that obsolete work items are removed.

## Epic E4: Team Collaboration
- US-007: As an authenticated user, I want to assign tasks to team members so that ownership is clear.

## Epic E5: Progress Tracking
- US-008: As an authenticated user, I want to update task status so that progress is visible.

## Epic E6: Task Discovery
- US-009: As an authenticated user, I want to search tasks so that I can find specific work quickly.
- US-010: As an authenticated user, I want to filter tasks by status so that I can focus on a subset.
