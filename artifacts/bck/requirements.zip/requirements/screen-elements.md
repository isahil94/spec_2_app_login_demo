# Screen Elements

## Dashboard
- Header: application title and navigation
- Task list: collection of tasks with title and status
- Filter controls: search input, status filter, assignee filter
- Task action buttons: create, edit, delete

## Authentication Screens
- Registration form: email, password, submit
- Login form: email, password, submit
- Error message region: validation and auth feedback

## Task Modal/Form
- Title input
- Description input
- Assignee selector
- Status selector
- Save and cancel actions
