# Non-Functional Requirements

## Security
- NFR-001: Authentication and authorization must be enforced on all protected task operations.
- NFR-002: Sensitive authentication data must be handled securely.

## Performance
- NFR-003: Task dashboard and list views should load with acceptable responsiveness for normal team usage.
- NFR-004: Search and status filtering should return results quickly for expected dataset sizes.

## Usability
- NFR-005: The application must be user-friendly and aligned with the provided Figma design intent.
- NFR-006: Validation and error messages must be clear and actionable.

## Compatibility and Responsiveness
- NFR-007: The application must be responsive across common desktop and mobile viewport sizes.
- NFR-008: Core workflows (login, task CRUD, assignment, status tracking, search/filter) must be usable on supported browsers.

## Reliability
- NFR-009: Saved task and assignment changes must persist reliably.
- NFR-010: The system must present consistent task status counts between dashboard and task list.
