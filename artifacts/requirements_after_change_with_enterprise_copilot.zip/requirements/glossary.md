# Glossary Template

## Purpose
Define business terms, acronyms, and domain concepts used by the project.

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03
- Status: Draft
- Workflow ID: task-management-ba

## Business Terms
| Term | Definition |
|---|---|
| Task Owner | The accountable user responsible for a task outcome. |
| Assignee | The user currently assigned to execute the task. |
| Reporter | The user who created or reported the task. |
| Archived Task | A read-only task retained for search and historical visibility. |
| Task Lifecycle | The sequence of allowed business status transitions for a task. |
| Role Matrix | The defined permission mapping for Administrator, Team Lead, and Team Member. |
| Dashboard Summary | Aggregated role-scoped view of task and activity indicators. |
| Workload Overview | Comparative view of task volume across users or teams. |
| Notification Trigger | Business event that causes a user alert. |
| Business Rule | Mandatory policy statement that governs behavior and validation. |
| Acceptance Criterion | Testable condition required for story acceptance. |
| Dependency-Unavailable State | Explicit user-visible state when required dependency cannot be reached. |

## Acronyms
| Acronym | Expansion |
|---|---|
| KPI | Key Performance Indicator |
| NFR | Non-Functional Requirement |
| RBAC | Role-Based Access Control |
| WCAG | Web Content Accessibility Guidelines |

## Domain Definitions
- Task Priority: Ordered urgency classification with values Low, Medium, High, Critical.
- Task Status: Progress state with values Todo, In Progress, Review, Completed, Blocked.
- Team Governance: Role-constrained capability to manage team membership and ownership.

## Key Concepts
- Auditability: Ability to verify who did what and when for every significant update.
- Traceability: Ability to map business goals through requirements, stories, and criteria.
- Role-Scoped Visibility: Users can only view and act on capabilities allowed by role and context.