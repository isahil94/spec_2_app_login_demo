# Acceptance Criteria

- AC-001 | Registration allows eligible users to create an account.
- AC-002 | Authentication controls access to protected task functionality.
- AC-003 | Dashboard presents current task summary information.
- AC-004 | Users can create tasks with required business information.
- AC-005 | Users can update task details within allowed scope.
- AC-006 | Users can delete tasks according to policy.
- AC-007 | Team leads can assign tasks to team members.
- AC-008 | Task status updates are reflected in user-visible views.
- AC-009 | Users can find tasks with search criteria.
- AC-010 | Users can narrow visible tasks using filters.
