# Acceptance Criteria

## AC-001: Registration
- Given a user has not created an account, when they submit registration details, then an account is created successfully.
- Given a user submits incomplete registration details, when they submit the form, then the system rejects the request and provides validation feedback.

## AC-002: Sign In
- Given a registered user, when they sign in with valid credentials, then they access the application.
- Given an invalid login attempt, when the user submits credentials, then the system denies access and displays an error.

## AC-003: Dashboard
- Given a signed-in user, when they open the dashboard, then they see their assigned and created tasks.

## AC-004: Task CRUD
- Given a signed-in user, when they create a task, then the task appears in the task list.
- Given an existing task, when the user edits it, then the updated details are persisted.
- Given an existing task, when the user deletes it, then it is removed from the list.

## AC-005: Assignment and Status
- Given a task exists, when it is assigned to a user, then the assignee is visible in the task details.
- Given a task exists, when its status changes, then the updated status is visible in the UI.

## AC-006: Search and Filter
- Given tasks exist, when a user searches by text, then matching tasks are shown.
- Given tasks exist, when a user filters by status or assignee, then only matching tasks are shown.

## AC-007: Responsive UI
- Given a user opens the application on a mobile or tablet viewport, when the interface loads, then the layout remains usable and aligned to the design system.
