# Design System

## Metadata
- Version: 1.0.0
- Author: UI/UX Developer Agent
- Date: 2026-07-01
- Status: Draft
- Figma Reference: https://www.figma.com/make/YnxUzBz6USzrnokLtV4Jd0/Task-Management-System-Screens?t=1gWarwbU89pAMBkw-1

## Foundations
- Typography: clear hierarchy with predictable heading and body scale.
- Color roles: primary action, neutral surfaces, semantic status colors, and accessible contrast pairs.
- Spacing: 4px base scale with consistent section rhythm.

## Tokens
- Status tokens: planned, active, completed.
- Surface tokens: page background, card background, elevated panel.
- Feedback tokens: success, warning, error, informational.

## Core Components
- AuthForm with required-field validation and submit states.
- TaskCard with title, status, assignee, and quick actions.
- FilterBar with text query, status filter, and assignee filter.
- TaskEditor fields for title, description, status, and assignee.

## Interaction States
- Buttons: default, hover, focus-visible, disabled, loading.
- Inputs: default, focus, error, disabled.
- Task items: default, selected, updating.

## Responsive Rules
- Keep control targets touch-friendly on mobile.
- Collapse dense dashboard controls into stacked groups below tablet width.
