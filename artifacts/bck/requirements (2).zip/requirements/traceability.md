# Traceability Matrix

## Metadata

- Version: 1.0.0
- Author: Business Analyst Agent
- Date: 2026-07-01
- Status: Draft
- Workflow ID: WF-20260701-001
- Traceability ID: TRACE-001

---

## Traceability Matrix

| Epic | Feature | Functional Requirement | User Story | Acceptance Criteria | Architecture Module | API Contract | Database Entity | UI Screen | Test Case | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| EPIC-001 | FEAT-001 | FR-001 | US-001 | AC-001, AC-002 | TBD | TBD | User | UI-001 | TBD | Partial |
| EPIC-001 | FEAT-001 | FR-002 | US-001 | AC-003, AC-004 | TBD | TBD | User | UI-001 | TBD | Partial |
| EPIC-001 | FEAT-002 | FR-003 | US-002 | AC-005, AC-006, AC-007 | TBD | TBD | User / Session | UI-002 | TBD | Partial |
| EPIC-001 | FEAT-002 | FR-004 | US-003 | AC-008 | TBD | TBD | Session | UI-002 (Nav) | TBD | Partial |
| EPIC-002 | FEAT-003 | FR-005 | US-004 | AC-009, AC-010, AC-011 | TBD | TBD | Task | UI-005 | TBD | Partial |
| EPIC-002 | FEAT-003 | FR-006 | US-005 | AC-012, AC-013 | TBD | TBD | Task | UI-006, UI-007 | TBD | Partial |
| EPIC-002 | FEAT-003 | FR-007 | US-006 | AC-014, AC-015 | TBD | TBD | Task | UI-006 | TBD | Partial |
| EPIC-002 | FEAT-003 | FR-008 | US-007 | AC-016 | TBD | TBD | Task | UI-004 | TBD | Partial |
| EPIC-002 | FEAT-003 | FR-009 | US-008 | AC-017 | TBD | TBD | Task | UI-006 | TBD | Partial |
| EPIC-003 | FEAT-004 | FR-010 | US-010 | AC-020, AC-021 | TBD | TBD | Task, User | UI-005, UI-007 | TBD | Partial |
| EPIC-003 | FEAT-004 | FR-011 | US-010 | AC-022 | TBD | TBD | Notification | UI-003 (Nav) | TBD | Partial |
| EPIC-002 | FEAT-005 | FR-012 | US-009 | AC-018, AC-019 | TBD | TBD | Task | UI-006, UI-004 | TBD | Partial |
| EPIC-002 | FEAT-005 | FR-013 | US-009 | AC-018 | TBD | TBD | Task | UI-006 | TBD | Partial |
| EPIC-004 | FEAT-006 | FR-014 | US-011 | AC-023 | TBD | TBD | Task | UI-003 | TBD | Partial |
| EPIC-004 | FEAT-006 | FR-015 | US-011 | AC-024 | TBD | TBD | Task | UI-003 | TBD | Partial |
| EPIC-005 | FEAT-007 | FR-016 | US-012 | AC-025, AC-026 | TBD | TBD | Task | UI-004 | TBD | Partial |
| EPIC-005 | FEAT-007 | FR-017 | US-013 | AC-027, AC-028 | TBD | TBD | Task | UI-004 | TBD | Partial |

> **Note:** Architecture Module, API Contract, and Test Case columns are marked TBD — these will be completed by the Solution Architect, Backend Developer, and QA Engineer agents respectively.

---

## Coverage Summary

| Dimension | Count | Notes |
|---|---|---|
| Epics Covered | 5 | EPIC-001 to EPIC-005 — all specification epics covered |
| Features Covered | 7 | FEAT-001 to FEAT-007 — all specification features covered |
| Functional Requirements Covered | 17 | FR-001 to FR-017 — all FRs covered |
| User Stories Covered | 13 | US-001 to US-013 — all stories covered |
| Acceptance Criteria Covered | 28 | AC-001 to AC-028 — all ACs covered |
| Architecture Modules | 0 | TBD — Solution Architect phase |
| API Contracts | 0 | TBD — Backend Developer phase |
| Database Entities (conceptual) | 3 | User, Task, Notification |
| UI Screens Mapped | 7 | UI-001 to UI-007 |
| Test Cases | 0 | TBD — QA Engineer phase |
| Missing Trace Links | 3 | Architecture module, API contract, test case columns pending |

---

## Missing Traceability

| Missing Item | Affected Row(s) | Resolution Stage |
|---|---|---|
| Architecture Module | All rows | Solution Architect — populate after architecture output |
| API Contract | All rows | Backend Developer — populate after API design |
| Test Case | All rows | QA Engineer — populate after test plan |
| Notification entity modelling | FR-011, US-010 | Database Developer — notification delivery model undefined |

---

## OpenLog References

- Record unresolved traceability gaps (notification model, API contract, test case) as tracked items in `openlog.md`.

---

## Notes

- All trace links are explicit and deterministic from specification to story to acceptance criteria.
- Conceptual database entities (User, Task, Notification) are business-level only; no schema or implementation details included.
- Architecture and API columns will be back-filled by downstream agents.
- This matrix is owned by the Business Analyst; downstream agents must not overwrite this file — they extend it in their own artifacts.
