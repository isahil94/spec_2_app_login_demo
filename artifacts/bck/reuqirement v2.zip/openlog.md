# OpenLog

## Policy

This is the single append-only governance log for open questions, assumptions, risks, decisions, and escalations.

## Entries

### Entry 001
- Date: 2026-07-01
- Type: Open Question
- ID: OQ-001
- Title: Canonical status lifecycle definition
- Details: The source specification requires status tracking but does not define the exact status set or transition constraints.
- Impact: Medium
- Owner: Product Stakeholder
- Stage: Business Analyst
- Status: Open

### Entry 002
- Date: 2026-07-01
- Type: Open Question
- ID: OQ-002
- Title: Permission matrix for edit and delete operations
- Details: The specification includes edit and delete capabilities but does not define role boundaries.
- Impact: High
- Owner: Product Stakeholder
- Stage: Business Analyst
- Status: Open

### Entry 003
- Date: 2026-07-01
- Type: Open Question
- ID: OQ-003
- Title: Registration field and identity policy depth
- Details: Required identity fields and account policy constraints are not explicitly listed.
- Impact: Medium
- Owner: Product Stakeholder
- Stage: Business Analyst
- Status: Open

### Entry 004
- Date: 2026-07-01
- Type: Assumption
- ID: ASM-001
- Title: Team context and collaboration scope
- Details: Assumed that users belong to one collaborative team context for task assignment and visibility.
- Impact: Medium
- Owner: Business Analyst
- Stage: Business Analyst
- Status: Active

### Entry 005
- Date: 2026-07-01
- Type: Risk
- ID: RSK-001
- Title: Role ambiguity could cause inconsistent authorization behavior
- Details: Without explicit role permissions, downstream design may diverge across implementation components.
- Impact: High
- Owner: Solution Architect
- Stage: Business Analyst
- Status: Open

### Entry 006
- Date: 2026-07-01
- Type: Decision
- ID: DEC-001
- Title: Centralize acceptance criteria
- Details: Acceptance criteria were intentionally centralized in acceptance_criteria.md and removed from user stories to enforce single source of truth.
- Impact: High
- Owner: Business Analyst
- Stage: Business Analyst
- Status: Closed

### Entry 007
- Date: 2026-07-01
- Type: Decision
- ID: DEC-002
- Title: Preserve Figma URL as immutable input reference
- Details: Figma URL from source specification preserved unchanged across artifacts and handoff.
- Impact: Medium
- Owner: Business Analyst
- Stage: Business Analyst
- Status: Closed

## Workflow Status

- Current Stage: Business Analyst
- Current State: READY
- Blocking Escalations: None
- Next Routing Decision: Supervisor may route to Solution Architect
