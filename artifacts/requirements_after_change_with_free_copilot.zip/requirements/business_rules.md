# Business Rules

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03

### Rule ID: BR-001
- Rule Name: Task Ownership
- Description: Every task must have exactly one owner.
- Business Justification: Ensures clear accountability.
- Applies To: All tasks
- Validation: Task creation requires owner field; system rejects owner-less tasks.
- Exception: N/A
- Priority: Critical
- Related Stories: US-001

### Rule ID: BR-002
- Rule Name: Single Assignee
- Description: A task may have at most one assignee.
- Business Justification: Prevents conflicting ownership during execution.
- Applies To: All tasks
- Validation: UI and backend enforce single assignee selection.
- Exception: N/A
- Priority: High
- Related Stories: US-001, US-003

### Rule ID: BR-003
- Rule Name: Permanent Delete Privilege
- Description: Only Administrators may permanently delete tasks.
- Business Justification: Prevent accidental data loss and preserve auditability.
- Applies To: Administrators
- Validation: Delete API checks role; UI hides permanent delete for non-admins.
- Exception: N/A
- Priority: High
- Related Stories: Administrative management stories
