# Business Rules

## Core Business Rules
1. Every task must be associated with a creator and a current state.
2. A task can only be assigned to an authenticated user with access to the workspace.
3. Task deletion should be restricted to authorized users and should be reflected in the task list.
4. Search and filtering must operate over visible task data only.
5. A task status must be represented consistently across dashboard and detail views.
6. Authentication must be required to access task management functionality.

## Derived Rules
- The system should prevent blank task titles or invalid values from being submitted.
- The dashboard should display a current view of tasks based on the latest persisted state.
- Users should be able to distinguish tasks by status and owner at a glance.

## Validation Notes
- Business rules should be validated during UI form submission and API processing.
- Any unsupported assumptions should be documented as open questions until clarified.
