# Stakeholders

- Product Owner | Owns scope and business outcomes.
- Team Lead | Owns assignment and progress monitoring.
- Team Member | Executes tasks and updates status.
- System Administrator | Supports account and access governance.
