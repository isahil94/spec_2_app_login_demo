# Acceptance Criteria

## Metadata
- Version: 1.1
- Author: Business Analyst Agent
- Date: 2026-07-03
- Status: Draft

## Acceptance Criteria by Story

### US-001 (Create Task)
- AC-001.1: Given an authenticated user, when the user submits a task with a Title <=100 chars and Due Date >= today, then the task is created and visible in Task List with a Task ID and audit record.
- AC-001.2: Given Title missing, when user submits, then validation error shown identifying Title as required.
- AC-001.3 (Dependency-Unavailable): If the task service is unavailable, the Create Task screen displays "Cannot create task — service unavailable" and the draft is preserved locally.

### US-002 (Edit Task)
- AC-002.1: Given user is owner, when editing a non-completed task with valid inputs, then changes persist and audit recorded.
- AC-002.2: Given task is Completed and user is non-Administrator, when attempting edit, then action is blocked and message "Completed tasks are read-only" is shown.
- AC-002.3 (Dependency-Unavailable): If save fails due to backend unreachability, UI shows explicit state: "Save failed — dependency unavailable" and keeps edits unsaved.

### US-003 (Search & Filter)
- AC-003.1: Search by title/description/labels returns matching tasks within expected response time (see NFRs).
- AC-003.2: Filters (status, priority, assignee, due date, team) can be combined and persist across pagination.
- AC-003.3 (Dependency-Unavailable): If search backend is unavailable, show the Task List in cached or empty state and a banner: "Search currently unavailable".

### US-005 (Notifications)
- AC-005.1: When a user is assigned a task, they receive an in-app notification and, if email enabled, an email within configured window.
- AC-005.2 (Dependency-Unavailable): If notification delivery service is unavailable, in-app notification still records local event and shows "Notifications delivery delayed".
