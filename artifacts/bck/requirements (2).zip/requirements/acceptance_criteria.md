# Acceptance Criteria

## Metadata

- Version: 1.0.0
- Author: Business Analyst Agent
- Date: 2026-07-01
- Status: Draft
- Workflow ID: WF-20260701-001
- Artifact ID: AC-MASTER-001
- Related Artifacts: user_stories.md, requirements_spec.md

> **Single Source of Truth:** All acceptance criteria are centralized here. User story files reference AC IDs only.

---

## US-001 — User Registration

### AC-001

**User Story:** US-001  
**Feature:** FEAT-001  
**Functional Requirement:** FR-001

**Given** a visitor is on the registration page  
**When** they submit a valid, unique email and a password meeting complexity requirements  
**Then** the system creates a new account and redirects the user to the login page

---

### AC-002

**User Story:** US-001  
**Feature:** FEAT-001  
**Functional Requirement:** FR-001

**Given** a visitor attempts to register with an email already in use  
**When** they submit the registration form  
**Then** the system displays an error message stating the email is already registered and does not create a duplicate account

---

### AC-003

**User Story:** US-001  
**Feature:** FEAT-001  
**Functional Requirement:** FR-002

**Given** a visitor submits the registration form  
**When** the email format is invalid  
**Then** the system displays an inline validation error indicating the email format is incorrect

---

### AC-004

**User Story:** US-001  
**Feature:** FEAT-001  
**Functional Requirement:** FR-002

**Given** a visitor submits the registration form  
**When** the password does not meet complexity requirements (minimum 8 characters, at least one uppercase, one lowercase, one digit)  
**Then** the system displays a validation error describing the unmet requirement

---

## US-002 — User Login

### AC-005

**User Story:** US-002  
**Feature:** FEAT-002  
**Functional Requirement:** FR-003

**Given** a registered user is on the login page  
**When** they submit their correct email and password  
**Then** the system authenticates the user, creates a session, and redirects to the dashboard

---

### AC-006

**User Story:** US-002  
**Feature:** FEAT-002  
**Functional Requirement:** FR-003

**Given** a user submits the login form  
**When** the email or password is incorrect  
**Then** the system displays a generic error ("Invalid email or password") without revealing which field is wrong

---

### AC-007

**User Story:** US-002  
**Feature:** FEAT-002  
**Functional Requirement:** FR-003

**Given** a user submits the login form  
**When** one or both fields are empty  
**Then** the system displays a validation error and does not attempt authentication

---

## US-003 — User Logout

### AC-008

**User Story:** US-003  
**Feature:** FEAT-002  
**Functional Requirement:** FR-004

**Given** an authenticated user triggers the logout action  
**When** the logout is processed  
**Then** the user's session is terminated, any session tokens are invalidated, and the user is redirected to the login page

---

## US-004 — Create a Task

### AC-009

**User Story:** US-004  
**Feature:** FEAT-003  
**Functional Requirement:** FR-005

**Given** an authenticated user is on the task creation form  
**When** they enter a valid title and submit  
**Then** the system creates the task with status "To Do" and displays it in the task list

---

### AC-010

**User Story:** US-004  
**Feature:** FEAT-003  
**Functional Requirement:** FR-005

**Given** an authenticated user submits the task creation form  
**When** the title field is empty  
**Then** the system displays a validation error and does not create the task

---

### AC-011

**User Story:** US-004  
**Feature:** FEAT-003  
**Functional Requirement:** FR-005

**Given** an authenticated user is creating a task  
**When** they provide an optional due date  
**Then** the system accepts only valid calendar dates and rejects past dates with an informative message

---

## US-005 — Edit a Task

### AC-012

**User Story:** US-005  
**Feature:** FEAT-003  
**Functional Requirement:** FR-006

**Given** the task creator or assignee is viewing a task detail  
**When** they edit one or more fields and save  
**Then** the system updates the task with the new values and displays a success confirmation

---

### AC-013

**User Story:** US-005  
**Feature:** FEAT-003  
**Functional Requirement:** FR-006

**Given** a user who is neither the creator nor the assignee views a task detail  
**When** they attempt to access the edit action  
**Then** the system does not present an edit option (or returns an error if accessed directly)

---

## US-006 — Delete a Task

### AC-014

**User Story:** US-006  
**Feature:** FEAT-003  
**Functional Requirement:** FR-007

**Given** the task creator is viewing a task  
**When** they initiate deletion and confirm the confirmation prompt  
**Then** the system deletes the task and it no longer appears in the task list, dashboard, or search results

---

### AC-015

**User Story:** US-006  
**Feature:** FEAT-003  
**Functional Requirement:** FR-007

**Given** a user who is not the task creator views a task  
**When** they attempt to delete it  
**Then** the system does not present a delete option (or returns a permission error if accessed directly)

---

## US-007 — View Task List

### AC-016

**User Story:** US-007  
**Feature:** FEAT-003  
**Functional Requirement:** FR-008

**Given** an authenticated user navigates to the task list  
**When** tasks exist in the system  
**Then** the system displays all non-deleted tasks visible to the user, showing at minimum: title, assignee, status, and priority

---

## US-008 — View Task Details

### AC-017

**User Story:** US-008  
**Feature:** FEAT-003  
**Functional Requirement:** FR-009

**Given** an authenticated user selects a task from the list  
**When** the task detail page loads  
**Then** the system displays all task fields: title, description, due date, priority, status, creator, and assignee (if assigned)

---

## US-009 — Update Task Status

### AC-018

**User Story:** US-009  
**Feature:** FEAT-005  
**Functional Requirement:** FR-012, FR-013

**Given** the task creator or assignee is viewing a task  
**When** they update the status to "In Progress" or "Done"  
**Then** the system persists the new status and reflects it in the task list and dashboard immediately

---

### AC-019

**User Story:** US-009  
**Feature:** FEAT-005  
**Functional Requirement:** FR-012

**Given** a user attempts to set an invalid status (not one of: To Do, In Progress, Done)  
**When** the update is submitted  
**Then** the system rejects the request and displays a validation error

---

## US-010 — Assign Task to Team Member

### AC-020

**User Story:** US-010  
**Feature:** FEAT-004  
**Functional Requirement:** FR-010

**Given** an authenticated user is creating or editing a task  
**When** they select a registered team member from the assignee picker and save  
**Then** the system assigns the task to that team member and the assignee is visible in the task detail and list

---

### AC-021

**User Story:** US-010  
**Feature:** FEAT-004  
**Functional Requirement:** FR-010

**Given** a user attempts to assign a task to a non-registered user  
**When** the assignment is submitted  
**Then** the system rejects the assignment and displays an error indicating the user is not registered

---

### AC-022

**User Story:** US-010  
**Feature:** FEAT-004  
**Functional Requirement:** FR-011

**Given** a task has been assigned to a team member  
**When** the assignment is saved  
**Then** the system delivers a notification to the assignee informing them of the new task assignment

---

## US-011 — View Dashboard

### AC-023

**User Story:** US-011  
**Feature:** FEAT-006  
**Functional Requirement:** FR-014

**Given** an authenticated user navigates to the dashboard  
**When** the dashboard loads  
**Then** the system displays the count of tasks in each status (To Do, In Progress, Done) scoped to the authenticated user's visible tasks

---

### AC-024

**User Story:** US-011  
**Feature:** FEAT-006  
**Functional Requirement:** FR-015

**Given** an authenticated user views the dashboard  
**When** tasks have been recently updated  
**Then** the system displays a list of recent activity (task updates) in reverse chronological order

---

## US-012 — Search Tasks

### AC-025

**User Story:** US-012  
**Feature:** FEAT-007  
**Functional Requirement:** FR-016

**Given** an authenticated user enters a keyword in the search box  
**When** they submit the search  
**Then** the system returns all non-deleted tasks whose title or description contains the keyword (case-insensitive), within 2 seconds

---

### AC-026

**User Story:** US-012  
**Feature:** FEAT-007  
**Functional Requirement:** FR-016

**Given** an authenticated user performs a search  
**When** no tasks match the keyword  
**Then** the system displays an empty state message indicating no results were found

---

## US-013 — Filter Tasks

### AC-027

**User Story:** US-013  
**Feature:** FEAT-007  
**Functional Requirement:** FR-017

**Given** an authenticated user applies one or more filters (status, assignee, priority, due date)  
**When** the filter is applied  
**Then** the system returns only non-deleted tasks matching all selected criteria

---

### AC-028

**User Story:** US-013  
**Feature:** FEAT-007  
**Functional Requirement:** FR-017

**Given** an authenticated user applies filters  
**When** no tasks match the selected filter criteria  
**Then** the system displays an empty state message and retains the filter selections for adjustment
