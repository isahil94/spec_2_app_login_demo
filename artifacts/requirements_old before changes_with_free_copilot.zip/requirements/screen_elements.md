# Screen Elements

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-02
- Status: Draft
- Workflow ID: task-management-ba

## Screen Contracts

### Login
- Purpose: Authenticate an existing user.
- Component or Section: Authentication

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Email Field | Input | Email | Enter your email | Yes | Must be a valid email address | None | Always visible in authentication flows | Enabled when the form is active | Account access requires a known email | Must be keyboard accessible |
| Password Field | Input | Password | Enter your password | Yes | Must meet password policy | None | Always visible in authentication flows | Enabled when the form is active | Password strength is required | Must support screen readers |
| Sign In Button | Button | Sign In | None | Yes | None | None | Always visible | Enabled when inputs are complete | Authenticated access is granted for valid credentials | Must have clear focus state |
| Forgot Password Link | Link | Forgot Password | None | No | None | None | Always visible | Enabled | Supports recovery workflow | Must be keyboard accessible |

---

### Register
- Purpose: Create a new account.
- Component or Section: Account creation

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Full Name Field | Input | Full Name | Enter your full name | Yes | Must be provided | None | Always visible | Enabled when the form is active | User identity must be captured | Must be keyboard accessible |
| Email Field | Input | Email | Enter your email | Yes | Must be a valid email address | None | Always visible | Enabled when the form is active | Account creation requires a valid email | Must support screen readers |
| Password Field | Input | Password | Enter your password | Yes | Must meet password policy | None | Always visible | Enabled when the form is active | Password strength is required | Must support screen readers |
| Create Account Button | Button | Create Account | None | Yes | None | None | Always visible | Enabled when required fields are valid | Valid registration creates an account | Must have clear focus state |

---

### Dashboard
- Purpose: Show workload and progress overview.
- Component or Section: Workspace overview

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Total Tasks Card | Read-only Text | Total Tasks | None | No | None | Current totals | Visible to authenticated users | Always enabled | Metrics must reflect current task state | Must be readable |
| Upcoming Deadlines Panel | Read-only Text | Upcoming Deadlines | None | No | None | None | Visible to authenticated users | Always enabled | Deadlines must reflect the user scope | Must be scannable |
| Recent Activity List | Read-only Text | Recent Activity | None | No | None | Latest events | Visible to authenticated users | Always enabled | Activity must reflect recent updates | Must support screen readers |

---

### Task List
- Purpose: Show and manage task collections.
- Component or Section: Task collection view

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Search Field | Input | Search | Search tasks | No | Must match supported search values | None | Visible to authenticated users | Enabled | Search must respect scope and permissions | Must be keyboard accessible |
| Filter Control | Select | Filter | Select a filter | No | Must match supported values | None | Visible to authenticated users | Enabled | Filtering must follow visible task scope | Must be screen-reader friendly |
| Sort Control | Select | Sort | Sort tasks | No | Must match supported values | Default sorting | Visible to authenticated users | Enabled | Sorting must use approved business fields | Must be keyboard accessible |
| Task List | Read-only Text | Tasks | None | No | None | Current task set | Visible to authorized users | Always enabled | Users see only tasks within scope | Must be scannable |

---

### Task Details
- Purpose: Show the full task record and collaboration history.
- Component or Section: Task detail view

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Task Title Field | Input | Title | Enter task title | Yes | Required and max 100 characters | None | Visible when the task is editable | Enabled when permitted | Task title is required | Must be keyboard accessible |
| Task Status Control | Select | Status | Select status | Yes | Must use approved task status values | Current status | Visible when task is accessible | Enabled when permitted | Status changes must follow lifecycle rules | Must be screen-reader friendly |
| Due Date Field | Date | Due Date | Select due date | No | Must not be earlier than today | None | Visible when task is accessible | Enabled when permitted | Due date must be valid | Must be keyboard accessible |
| Comment Input | Input | Comment | Add a comment | No | Must fit allowed business limits | None | Visible when task access exists | Enabled when permitted | Comments must be linked to the task | Must be keyboard accessible |

---

### Create Task / Edit Task
- Purpose: Capture or update task details.
- Component or Section: Task form

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Title Field | Input | Title | Enter task title | Yes | Required and max 100 characters | None | Visible to authorized users | Enabled when form is active | Title is required | Must be keyboard accessible |
| Description Field | Input | Description | Describe the task | No | Max 2000 characters | None | Visible to authorized users | Enabled when form is active | Description may be optional | Must support screen readers |
| Priority Select | Select | Priority | Select priority | Yes | Must use approved priority values | None | Visible to authorized users | Enabled when form is active | Priority is required | Must be keyboard accessible |
| Save Button | Button | Save | None | Yes | None | None | Visible to authorized users | Enabled when required values are valid | Task is saved when business rules are met | Must have clear focus state |

---

### Profile
- Purpose: Manage personal profile information.
- Component or Section: User profile

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Name Field | Input | Name | Enter your name | Yes | Must be provided | Current profile name | Visible to the logged-in user | Enabled when the profile is editable | Profile data is scoped to the current account | Must be keyboard accessible |
| Avatar Upload | Input | Avatar | None | No | Must use acceptable file type | Current avatar | Visible to the logged-in user | Enabled when profile settings are editable | Avatar updates apply to the user account | Must be screen-reader friendly |
| Password Change Field | Input | Password | Enter a new password | No | Must meet password policy | None | Visible to authorized users | Enabled when password update is requested | Password changes must follow policy | Must support screen readers |

---

### Settings
- Purpose: Configure preferences and defaults.
- Component or Section: Preferences and defaults

#### Elements
| Element Name | Element Type | Label | Placeholder | Required | Validation Rules | Default Value | Visibility Rules | Enabled/Disabled Rules | Business Rules | Accessibility Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Theme Selector | Select | Theme | Select theme | No | Must use supported values | Current theme | Visible to authenticated users | Enabled | Theme values must match supported options | Must be keyboard accessible |
| Notification Preferences | Toggle | Notifications | None | No | Must use supported settings | Current preference | Visible to authenticated users | Enabled | Preferences must be saved per account | Must be screen-reader friendly |
| Language Selector | Select | Language | Select language | No | Must use supported values | Current language | Visible to authenticated users | Enabled | Language changes must be persisted | Must be keyboard accessible |
