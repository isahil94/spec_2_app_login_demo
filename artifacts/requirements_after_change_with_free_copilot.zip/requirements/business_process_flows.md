# Business Process Flows

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03

### Process Name: Create Task
- Objective: Allow authenticated users to create a task and record audit information.
- Trigger: User selects Create Task and submits required fields.
- Preconditions: Authenticated session; Title provided
- Main Flow:
  1. User opens Create Task screen
  2. User fills Title, optional Description, Priority, Due Date
  3. User submits
  4. System validates inputs
  5. System creates Task and AuditEvent
  6. Task appears in Task List and Dashboard metrics update
- Postconditions: New Task in system; audit recorded; notifications sent if assignee set
- Related Stories: US-001
- Related Screens: Create Task, Task List

```mermaid
flowchart TD
  A[Open Create Task] --> B[Fill fields]
  B --> C{Validation}
  C -- OK --> D[Create Task & Audit]
  C -- Error --> E[Show validation errors]
  D --> F[Notify assignee]
  D --> G[Update dashboard]
```

### Process Name: Task Lifecycle (Status Transitions)
- Objective: Enforce allowed status transitions and read-only rules for Completed/Archived states.
- Trigger: User or system action to change status
- Preconditions: Task exists
- Main Flow:
  1. User changes status following allowed transitions (Todo->In Progress->Review->Completed)
  2. System validates transition
  3. System records audit
  4. If transition to Completed, enforce read-only for non-admins
- Related Stories: US-002

```mermaid
stateDiagram-v2
  [*] --> Todo
  Todo --> InProgress : Start work
  InProgress --> Review : Request review
  Review --> Completed : Approve
  Review --> InProgress : Rework
  Completed --> Archived : Archive
```
