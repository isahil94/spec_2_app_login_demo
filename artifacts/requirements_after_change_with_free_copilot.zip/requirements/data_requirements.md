# Data Requirements

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03

## Business Entities

### Entity: Task
- Business Meaning: Unit of work tracked by the system
- Owner: Task creator (business owner responsibility)
- Required Attributes: Task ID, Title, Status, Priority, Owner, Created Date
- Optional Attributes: Description, Assignee, Labels, Attachments, Due Date
- Relationships: Owned by User; may be assigned to User; belongs to Team (optional)
- Lifecycle: Todo -> In Progress -> Review -> Completed -> Archived
- Retention: Immutable history retained; archival preserves read-only copy
- PII Classification: None (may include user contact references)

### Entity: User
- Business Meaning: Person with account and roles
- Owner: Organization Admin
- Required Attributes: User ID, Email, Role, Display Name
- Optional Attributes: Avatar, Contact Info
- Relationships: Member of Team, Reporter/Assignee of Tasks
- Retention: Managed per organization policies
- PII Classification: Internal

### Entity: Team
- Business Meaning: Logical group of users for assignment and reporting
- Required Attributes: Team ID, Name, Owners
- Optional Attributes: Description
- Relationships: Has many Users; aggregates Tasks
- PII Classification: None
