# Business Process Flows Template

## Purpose
Document business workflows in a technology-agnostic manner for the Business Analyst stage.

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03
- Workflow ID: task-management-ba
- Status: Draft

## Business Process Flows

### Process Name: Authentication and Session Lifecycle
- Objective: Provide secure access to protected task-management capabilities.
- Trigger: Public user submits registration/login or password reset request.
- Preconditions: User account exists for login/reset; session absent for public routes.
- Main Flow:
  1. User opens Login/Register.
  2. User submits valid credentials or registration details.
  3. System grants authenticated session and routes to Dashboard.
- Alternate Flow:
  1. User selects Forgot Password.
  2. User completes password reset and returns to Login.
- Exception Flow:
  1. Invalid credentials/token submitted.
  2. Access denied and user remains in auth context.
- Postconditions: Authenticated users can access protected screens; unauthenticated users cannot.
- Related User Stories: US-001, US-002, US-003
- Related Screens: Login, Register, Reset Password, Dashboard
- Related Business Rules: BR-010, BR-011
- Related Acceptance Criteria: AC-001 to AC-012

```mermaid
flowchart TD
    A[Public User Opens Auth Screen] --> B{Action Type}
    B -->|Register| C[Submit Registration]
    B -->|Login| D[Submit Credentials]
    B -->|Forgot Password| E[Request Reset]
    C --> F{Valid Input?}
    D --> G{Valid Credentials?}
    E --> H{Reset Context Valid?}
    F -->|Yes| I[Account Created]
    F -->|No| J[Show Validation Errors]
    G -->|Yes| K[Start Session and Route to Dashboard]
    G -->|No| L[Show Access Denied]
    H -->|Yes| M[Password Updated and Return to Login]
    H -->|No| N[Show Reset Error]
```

### Process Name: Task Lifecycle and State Management
- Objective: Ensure tasks move through controlled lifecycle states with role-safe edits.
- Trigger: Authorized user creates, edits, transitions, archives, or restores tasks.
- Preconditions: User authenticated; task exists for update actions.
- Main Flow:
  1. User creates task with required fields.
  2. Task progresses through allowed status transitions.
  3. User updates task details and collaboration entries.
- Alternate Flow:
  1. Review state returns to In Progress for rework.
  2. Archived task is restored by permitted role.
- Exception Flow:
  1. Invalid transition or unauthorized action attempted.
  2. Action rejected and existing task state retained.
- Postconditions: Task records remain auditable, searchable, and policy-compliant.
- Related User Stories: US-005, US-006, US-008, US-009
- Related Screens: Task List, Task Details, Create Task, Edit Task
- Related Business Rules: BR-001, BR-002, BR-003, BR-004, BR-005, BR-006, BR-007, BR-008, BR-009
- Related Acceptance Criteria: AC-017 to AC-036

```mermaid
flowchart TD
    A[Create Task] --> B[Todo]
    B --> C[In Progress]
    C --> D[Review]
    D --> E[Completed]
    D --> C
    F[Blocked] --> C
    B --> G[Archived]
    C --> G
    D --> G
    E --> G
    G --> H{Restore Allowed?}
    H -->|Yes| B
    H -->|No| I[Remain Archived Read Only]
    E --> J{Non Admin Edit Attempt}
    J -->|Yes| K[Reject Edit]
```

### Process Name: User and Team Governance
- Objective: Maintain controlled user and team administration aligned with role permissions.
- Trigger: Administrator or Team Lead initiates user/team management action.
- Preconditions: Actor has governance permission for requested scope.
- Main Flow:
  1. Actor opens management area.
  2. Actor submits invite/disable/reset/role/team action.
  3. System applies valid action and records audit entry.
- Alternate Flow:
  1. Team Lead performs team-scope action only.
  2. Administrator performs organization-wide action.
- Exception Flow:
  1. Unauthorized role attempts governance action.
  2. Action denied and no state change occurs.
- Postconditions: User/team state is updated only for authorized operations.
- Related User Stories: US-011
- Related Screens: Settings, Dashboard
- Related Business Rules: BR-002, BR-011
- Related Acceptance Criteria: AC-041 to AC-044

```mermaid
flowchart TD
    A[Open User or Team Management] --> B{Role Check}
    B -->|Administrator| C[Allow User and Team Actions]
    B -->|Team Lead| D[Allow Team Scope Actions]
    B -->|Team Member| E[Deny Action]
    C --> F[Persist Change and Audit]
    D --> G{Within Team Scope?}
    G -->|Yes| F
    G -->|No| E
    E --> H[Show Permission Denied]
```

### Process Name: Reporting and Workload Insight
- Objective: Provide authorized operational insight into productivity and workload.
- Trigger: Authorized actor requests a report.
- Preconditions: Actor has report permission; report data source available.
- Main Flow:
  1. Actor selects report type and period.
  2. System compiles report within actor scope.
  3. Report view renders summary.
- Alternate Flow:
  1. Actor switches report type.
  2. Updated report view is displayed.
- Exception Flow:
  1. No data or dependency unavailable.
  2. No-data or unavailable state shown.
- Postconditions: Actor receives report state aligned to role and data availability.
- Related User Stories: US-012
- Related Screens: Dashboard
- Related Business Rules: BR-011
- Related Acceptance Criteria: AC-045 to AC-048

```mermaid
flowchart TD
    A[Authorized Actor Opens Reports] --> B[Select Type and Period]
    B --> C{Data Available?}
    C -->|Yes| D[Render Report]
    C -->|No Data| E[Show No Data State]
    C -->|Dependency Unavailable| F[Show Reporting Dependency Unavailable State]
    D --> G[Log Report Access]
```

## Notes
- Keep the content business-oriented and implementation-neutral.
- Do not include APIs, database, services, sequence diagrams, or infrastructure.