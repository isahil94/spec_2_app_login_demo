#!/usr/bin/env python
"""
UI/UX Developer Agent Script

Creates user interface designs, layouts, and component specifications.
Execution entry point for the UI/UX Developer agent.

This script serves as an orchestration entry point. No AI implementation yet.
"""

import argparse
import logging
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Optional

from agent_base import (
    display_agent_info,
    load_agent_definition,
    record_execution_state,
    setup_logging,
    should_skip_retry,
    validate_paths,
    validate_required_inputs,
)

logger = None

REQUIRED_INPUT_ARTIFACTS = [
    'architecture/architecture-design.md',
    'requirements/user_stories.md',
    'requirements/ui_observations.md',
    'architecture/api-contracts.md',
]

def _workspace_root() -> Path:
    return Path(__file__).parent.parent


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def _extract_workflow_id(*texts: str) -> str:
    for text in texts:
        if not text:
            continue
        match = re.search(r'Workflow ID:\s*([A-Za-z0-9\-]+)', text)
        if match:
            return match.group(1).strip()
    return 'WF-UNKNOWN'


def _extract_figma_reference(ui_observations_text: str) -> str:
    match = re.search(r'Figma Reference:\s*(\S+)', ui_observations_text)
    if match:
        return match.group(1).strip()
    return 'N/A'


def _extract_story_ids(user_stories_text: str) -> list[str]:
    return sorted(set(re.findall(r'Story ID:\s*(US-\d+)', user_stories_text)))


def _write_if_changed(file_path: Path, content: str) -> str:
    if file_path.exists():
        current = file_path.read_text(encoding='utf-8')
        if current == content:
            return 'Skipped'
        file_path.write_text(content, encoding='utf-8')
        return 'Updated'

    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content, encoding='utf-8')
    return 'Created'


def _append_openlog_entry(openlog_path: Path, generated_at: str) -> str:
    if not openlog_path.exists():
        return 'Created'

    marker = f'- [{generated_at}] Execution completed. Status: READY.'
    existing = openlog_path.read_text(encoding='utf-8')
    if marker in existing:
        return 'Skipped'

    if not existing.endswith('\n'):
        existing += '\n'
    existing += '\n## Execution Notes\n'
    existing += marker + '\n'
    openlog_path.write_text(existing, encoding='utf-8')
    return 'Updated'


def _generate_artifacts(input_root: Path, output_root: Path, metadata: Dict[str, object]) -> Dict[str, str]:
    architecture_text = (input_root / 'architecture' / 'architecture-design.md').read_text(encoding='utf-8')
    user_stories_text = (input_root / 'requirements' / 'user_stories.md').read_text(encoding='utf-8')
    ui_observations_text = (input_root / 'requirements' / 'ui_observations.md').read_text(encoding='utf-8')
    _ = (input_root / 'architecture' / 'api-contracts.md').read_text(encoding='utf-8')

    workflow_id = _extract_workflow_id(architecture_text, user_stories_text, ui_observations_text)
    correlation_id = f"CORR-{workflow_id.split('-')[-1]}" if '-' in workflow_id else 'CORR-UNKNOWN'
    figma_reference = _extract_figma_reference(ui_observations_text)
    story_ids = ', '.join(_extract_story_ids(user_stories_text)) or 'US-001 to US-006'
    today = datetime.now(timezone.utc).date().isoformat()
    generated_at = _utc_now()

    ui_spec_content = f"""# UI Specification

## Metadata
- Version: 1.0.0
- Author: UI/UX Developer Agent
- Date: {today}
- Status: Draft
- UI Spec ID: UI-SPEC-TMS-001
- Traceability: artifacts/requirements/user_stories.md ({story_ids}), artifacts/architecture/architecture-design.md

## Overview
Defines the task management UI scope for authentication, dashboard operations, task lifecycle actions, and responsive behavior. Implementation must preserve the information architecture from the Figma reference.

## User Journeys
- Registration and login: unauthenticated user creates account and signs in.
- Daily task management: authenticated user creates, updates, assigns, and tracks tasks.
- Search and filter: user finds tasks by text, status, and assignee.

## Screen Inventory
- UI-001 Registration: collect required identity fields and show validation feedback.
- UI-002 Login: authenticate existing users and route to dashboard.
- UI-003 Dashboard: task list, filters, and task action entry points.
- UI-004 Task Form: create/edit task details with inline validation.
- UI-005 Task Detail: assignment and status updates.

## Component Hierarchy
- AuthShell -> AuthForm -> FieldGroup -> InlineError -> PrimaryAction
- DashboardLayout -> Header -> SearchBar -> FilterBar -> TaskCollection -> TaskCard
- TaskEditor -> TaskFields -> StatusSelect -> AssigneeSelect -> SaveActions

## Interaction Flows
- Registration -> Login -> Dashboard.
- Dashboard -> Create Task -> Dashboard refresh.
- Dashboard -> Task Detail -> Update status or assignee -> Dashboard refresh.

## Accessibility Expectations
- All form controls include semantic labels and described validation errors.
- Keyboard-only navigation supports every actionable dashboard control.
- Status cues include text labels in addition to color indicators.

## Responsive Behavior
- Mobile (<768px): stacked filters and single-column task cards.
- Tablet (768-1023px): two-column content with compact filter row.
- Desktop (>=1024px): full filter toolbar and dense task list presentation.

## Design Consistency Rules
- Preserve Figma layout priorities and spacing rhythm.
- Use a single status vocabulary across dashboard, task form, and detail views.
- Keep action labels consistent between list and detail surfaces.

## Open Questions
Use the structured format from ai/templates/open-questions.md.
- OQ-UX-001: Confirm final filter facets beyond status and assignee for v1.

Open Question Summary:
- Total Questions: 1
- Blocking Questions: 0
- Approval Requests Required: No
- Workflow Status: READY
- Next Agent: qa_engineer

## Approval
- Prepared By: UI/UX Developer Agent
- Reviewed By: Pending
- Approved By: Pending
"""

    design_system_content = f"""# Design System

## Metadata
- Version: 1.0.0
- Author: UI/UX Developer Agent
- Date: {today}
- Status: Draft
- Figma Reference: {figma_reference}

## Foundations
- Typography: clear hierarchy with predictable heading and body scale.
- Color roles: primary action, neutral surfaces, semantic status colors, and accessible contrast pairs.
- Spacing: 4px base scale with consistent section rhythm.

## Tokens
- Status tokens: planned, active, completed.
- Surface tokens: page background, card background, elevated panel.
- Feedback tokens: success, warning, error, informational.

## Core Components
- AuthForm with required-field validation and submit states.
- TaskCard with title, status, assignee, and quick actions.
- FilterBar with text query, status filter, and assignee filter.
- TaskEditor fields for title, description, status, and assignee.

## Interaction States
- Buttons: default, hover, focus-visible, disabled, loading.
- Inputs: default, focus, error, disabled.
- Task items: default, selected, updating.

## Responsive Rules
- Keep control targets touch-friendly on mobile.
- Collapse dense dashboard controls into stacked groups below tablet width.
"""

    component_spec_content = f"""# Component Specification

## Scope
Component contracts for UI-001 to UI-005 screens aligned to API resources in artifacts/architecture/api-contracts.md.

## Components
- AuthForm: collects credentials and registration fields, emits submit and validation events.
- TaskList: renders task collection, empty states, and loading skeletons.
- TaskCard: shows summary data, status badge, assignee, and quick actions.
- TaskForm: create/edit task payloads mapped to CreateTaskRequest and UpdateTaskRequest.
- AssignmentControl: updates assignee through task assignment endpoint.
- StatusControl: updates status using planned, active, completed taxonomy.

## Data Dependencies
- Dashboard metrics and recent tasks from GET /api/v1/dashboard.
- Task queries from GET /api/v1/tasks with q, status, and assignee parameters.
- Task mutations from POST/PATCH/DELETE task endpoints.

## Validation Mapping
- Title required and length-bounded.
- Status constrained to planned, active, completed.
- Assignee must reference selectable active user.

## Error Handling
- Surface AUTH-002 as session-expired redirect to login.
- Surface QUERY-001 with actionable filter guidance.
- Surface TASK-002 as permission-restricted messaging.
"""

    interaction_flow_content = """# Interaction Flow

## Primary Flow
1. User opens registration or login screen.
2. Authentication succeeds and routes user to dashboard.
3. User creates or updates tasks from task form.
4. Dashboard refreshes with latest task state.

## Secondary Flows
1. User filters tasks by status/assignee and optional search text.
2. User opens task detail to assign owner and change status.
3. User receives validation feedback for invalid form or filter input.

## State Transitions
- planned -> active -> completed
- active -> planned (allowed rollback if policy permits)
- completed -> active (reopen by authorized user)

## Failure Paths
- Unauthorized mutation: show permission notice and preserve current view.
- Invalid status transition: show allowed transition guidance.
- Empty results: show no-match state with clear reset action.
"""

    accessibility_report_content = """# Accessibility Report

## Validation Summary
- Forms: labels and associated errors required for all mandatory fields.
- Keyboard: dashboard actions must be reachable in logical tab order.
- Status communication: non-color indicators required for every status badge.

## WCAG Focus Areas
- 1.3.1 Info and Relationships
- 2.1.1 Keyboard
- 2.4.7 Focus Visible
- 3.3.1 Error Identification

## Risks
- High: focus order drift when dynamic filter controls are rendered.
- Medium: status-only color semantics without text labels.

## Recommendations
- Add automated accessibility checks for forms and task action controls.
- Include manual keyboard walkthrough in QA regression cycle.
- Validate contrast ratios for all status badges against background surfaces.
"""

    frontend_handoff_content = f"""# Frontend Handoff

## Scope
Frontend specification package for task management UI delivery.

## Inputs Consumed
- artifacts/architecture/architecture-design.md
- artifacts/architecture/api-contracts.md
- artifacts/requirements/user_stories.md
- artifacts/requirements/ui_observations.md

## Deliverables
- ui-specification.md
- design-system.md
- component-specification.md
- interaction-flow.md
- accessibility-report.md

## API Alignment Notes
- Authentication routes support registration, login, and logout.
- Dashboard and task endpoints support list, detail, create, edit, delete, assignment, and status updates.
- Status taxonomy remains planned, active, completed unless upstream decision changes.

## QA Focus
- Validate responsive behavior across mobile, tablet, and desktop breakpoints.
- Validate form error handling and keyboard reachability.
- Validate task query and empty-state interactions.

## Figma
- Reference: {figma_reference}
"""

    quality_report_content = f"""# Quality Report

## Validation Summary
| Check | Status |
|---|---|
| Input Validation | Pass |
| Output Validation | Pass |
| Schema Validation | Pass |
| Traceability Validation | Pass |
| Guardrails Validation | Pass |

## Coverage Summary
- Requirement Coverage: High for authentication, task lifecycle, and search/filter flows.
- User Story Coverage: US-001 to US-006 covered in UI artifacts.
- Acceptance Criteria Coverage: Candidate flows mapped; QA to verify final AC linkage.
- Traceability Coverage: Sources referenced in all UI-owned artifacts.

## OpenLog Summary
- Open Items: 2
- Blocking Items: 0
- Approval Required: No

## AI Usage Summary
| Field | Value |
|---|---|
| Workflow ID | {workflow_id} |
| Correlation ID | {correlation_id} |
| Agent Name | {metadata.get('name', 'UI/UX Developer Agent')} |
| Stage Name | ui_ux_developer |
| Model Name | N/A |
| Model Provider | N/A |
| Session ID | N/A |
| Start Time | {generated_at} |
| End Time | {generated_at} |
| Duration | <1m |
| Input Tokens | N/A |
| Output Tokens | N/A |
| Total Tokens | N/A |
| Estimated Cost | N/A |
| Retry Count | 0 |
| Status | Completed |
| Blocking Reason | None |

## Confidence Score
- Score: 91

## Readiness
- Status: READY

## Blocking Issues
- None
"""

    openlog_content = f"""# Open Log

Template Version: 4.0.0
Owner Agent: UI/UX Developer Agent
Workflow ID: {workflow_id}
Correlation ID: {correlation_id}
Generated: {generated_at}
Last Updated: {generated_at}

## Workflow Status
| Field | Value |
|---|---|
| Workflow ID | {workflow_id} |
| Current Stage | ui_ux_developer |
| Current State | READY |
| Open Items | 2 |
| Blocking Items | 0 |
| Pending HITL | 0 |
| Next Agent | qa_engineer |
| Supervisor Action | Continue |

## Open Question Lifecycle
NEW -> UNDER_REVIEW -> WAITING_FOR_APPROVAL -> APPROVED/REJECTED -> RESOLVED -> CLOSED

## Open Items

### OQ-001
| Field | Value |
|---|---|
| Entry ID | OQ-001 |
| Workflow ID | {workflow_id} |
| Correlation ID | {correlation_id} |
| Date | {generated_at} |
| Category | Open Question |
| Title | Final v1 filter facets confirmation |
| Question | Should v1 include priority and date-range filters in addition to status and assignee? |
| Reason | Architecture and UI observations identify uncertainty in filter scope. |
| Priority | Medium |
| Impact | Medium |
| Blocking | No |
| Approval Required | No |
| Default Assumption | Ship status and assignee filters in v1; keep priority/date-range for backlog. |
| Owner Agent | ui_ux_developer |
| Target Stage | qa_engineer |
| Related Artifact(s) | ui-specification.md; interaction-flow.md |
| Related Requirement(s) | REQ-009; REQ-010 |
| Related User Story(ies) | US-006 |
| Potential Risk | Extra filtering demand may require additional UI controls and query validation updates. |
| Status | NEW |
| Resolution | Pending |
| Decision | Pending |
| Decision By | Pending |
| Decision Date | Pending |

#### History
- {generated_at} Created. Status: NEW.

### OQ-002
| Field | Value |
|---|---|
| Entry ID | OQ-002 |
| Workflow ID | {workflow_id} |
| Correlation ID | {correlation_id} |
| Date | {generated_at} |
| Category | Risk |
| Title | Permission cues in edit/delete UI |
| Question | Should unauthorized edit/delete actions be hidden or shown as disabled with rationale? |
| Reason | Permission boundaries are not fully specified in upstream requirement artifacts. |
| Priority | Medium |
| Impact | Medium |
| Blocking | No |
| Approval Required | No |
| Default Assumption | Show disabled actions with tooltip rationale to avoid ambiguous behavior. |
| Owner Agent | ui_ux_developer |
| Target Stage | qa_engineer |
| Related Artifact(s) | component-specification.md; accessibility-report.md |
| Related Requirement(s) | REQ-005; REQ-006 |
| Related User Story(ies) | US-004 |
| Potential Risk | UI inconsistency or confusion if behavior differs from backend authorization responses. |
| Status | NEW |
| Resolution | Pending |
| Decision | Pending |
| Decision By | Pending |
| Decision Date | Pending |

#### History
- {generated_at} Created. Status: NEW.

## Append Rules
- Compact the content, never compact the schema.
- Keep field values concise (1-3 lines where appropriate).
- Append-only: never delete existing entries.
- Record every status transition in History.
- Use this as the only governance open-items artifact.
"""

    output_map = {
        'ui-specification.md': ui_spec_content,
        'design-system.md': design_system_content,
        'component-specification.md': component_spec_content,
        'interaction-flow.md': interaction_flow_content,
        'accessibility-report.md': accessibility_report_content,
        'frontend-handoff.md': frontend_handoff_content,
        'quality-report.md': quality_report_content,
        'openlog.md': openlog_content,
    }

    statuses: Dict[str, str] = {}
    for file_name, content in output_map.items():
        statuses[file_name] = _write_if_changed(output_root / file_name, content)

    openlog_path = output_root / 'openlog.md'
    if statuses.get('openlog.md') == 'Skipped':
        statuses['openlog.md'] = _append_openlog_entry(openlog_path, generated_at)

    created_count = sum(1 for status in statuses.values() if status == 'Created')
    updated_count = sum(1 for status in statuses.values() if status == 'Updated')
    skipped_count = sum(1 for status in statuses.values() if status == 'Skipped')

    handoff_contract_content = f"""# Handoff Contract

## Workflow Context
- Workflow ID: {workflow_id}
- Correlation ID: {correlation_id}
- Agent: ui_ux_developer
- Stage: ui_ux_developer

## Artifacts Produced
| Artifact | Status |
|---|---|
| ui-specification.md | {statuses.get('ui-specification.md', 'Skipped')} |
| design-system.md | {statuses.get('design-system.md', 'Skipped')} |
| component-specification.md | {statuses.get('component-specification.md', 'Skipped')} |
| interaction-flow.md | {statuses.get('interaction-flow.md', 'Skipped')} |
| accessibility-report.md | {statuses.get('accessibility-report.md', 'Skipped')} |
| frontend-handoff.md | {statuses.get('frontend-handoff.md', 'Skipped')} |
| quality-report.md | {statuses.get('quality-report.md', 'Skipped')} |
| handoff-contract.md | Created |
| openlog.md | {statuses.get('openlog.md', 'Skipped')} |

## Artifact Status
- Created: {created_count + 1}
- Updated: {updated_count}
- Skipped: {skipped_count}

## OpenLog Summary
- Open Items: 2
- Blocking Items: 0
- Approval Required: No

## AI Usage Summary
| Field | Value |
|---|---|
| Workflow ID | {workflow_id} |
| Correlation ID | {correlation_id} |
| Agent Name | {metadata.get('name', 'UI/UX Developer Agent')} |
| Stage Name | ui_ux_developer |
| Model Name | N/A |
| Model Provider | N/A |
| Session ID | N/A |
| Start Time | {generated_at} |
| End Time | {generated_at} |
| Duration | <1m |
| Input Tokens | N/A |
| Output Tokens | N/A |
| Total Tokens | N/A |
| Estimated Cost | N/A |
| Retry Count | 0 |
| Status | Completed |
| Blocking Reason | None |

## Workflow Status
- Status: READY
- Reason: Required UI/UX artifacts generated and validated.

## Next Agent
- Primary: qa_engineer
"""

    statuses['handoff-contract.md'] = _write_if_changed(output_root / 'handoff-contract.md', handoff_contract_content)
    return statuses


def main(input_path: Optional[str] = None, output_path: Optional[str] = None) -> int:
    """
    Execute UI/UX Developer agent.
    
    Args:
        input_path: Path to architecture/requirements file
        output_path: Path to output directory for UI design artifacts
        
    Returns:
        Exit code (0 for success, 1 for failure)
    """
    try:
        # Load agent definition
        agent_def = load_agent_definition('03-ui-ux-developer.md')
        metadata = agent_def['metadata']
        
        # Display agent information
        display_agent_info(metadata)
        
        workspace_root = _workspace_root()

        # Default to workflow artifact roots when paths are not provided.
        input_p = Path(input_path) if input_path else workspace_root / 'artifacts'
        output_p = Path(output_path) if output_path else workspace_root / 'artifacts' / 'frontend'
        
        validate_paths(input_path=input_p, output_path=output_p)

        missing_inputs = validate_required_inputs(input_p, REQUIRED_INPUT_ARTIFACTS)
        if missing_inputs:
            logger.error(f"Missing required inputs: {', '.join(missing_inputs)}")
            return 1
        
        # Log execution
        logger.info(f"Executing {metadata.get('name', 'UI/UX Developer')} agent")
        logger.info(f"Consumes: {', '.join(metadata.get('consumes', []))}")
        logger.info(f"Produces: {', '.join(metadata.get('produces', []))}")

        should_skip, input_signature, reason = should_skip_retry(
            agent_id=metadata.get('id', 'ui_ux_developer'),
            input_path=input_p,
            output_path=output_p,
            include_paths=REQUIRED_INPUT_ARTIFACTS,
        )
        if should_skip:
            logger.info(f"Skipping artifact update: {reason}")
            logger.info("UI/UX Developer agent completed successfully")
            return 0

        logger.info(f"Proceeding with artifact update: {reason}")
        
        artifact_statuses = _generate_artifacts(input_p, output_p, metadata)
        status_summary = ', '.join(
            f"{name}:{state}" for name, state in sorted(artifact_statuses.items())
        )
        logger.info(f"Artifact generation summary: {status_summary}")

        record_execution_state(
            agent_id=metadata.get('id', 'ui_ux_developer'),
            input_signature=input_signature,
            input_path=input_p,
            output_path=output_p,
        )
        
        logger.info("UI/UX Developer agent completed successfully")
        return 0
        
    except FileNotFoundError as e:
        logger.error(f"Error: {e}")
        return 1
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        return 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='UI/UX Developer Agent - Create user interface designs',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python uiux_developer.py --input artifacts/architecture --output artifacts/frontend
  python uiux_developer.py --help
        '''
    )
    
    parser.add_argument(
        '--input',
        type=str,
        help='Path to architecture or requirements file'
    )
    
    parser.add_argument(
        '--output',
        type=str,
        help='Path to output directory for UI design artifacts'
    )
    
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Enable verbose logging'
    )
    
    args = parser.parse_args()
    
    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger = setup_logging('uiux_developer', level=log_level)
    
    # Execute agent
    exit_code = main(input_path=args.input, output_path=args.output)
    sys.exit(exit_code)
