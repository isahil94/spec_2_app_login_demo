# Assumptions

- ASM-001: The supplied Figma reference reflects intended UX direction.
- ASM-002: Task assignment is single-owner unless otherwise approved.
- ASM-003: Initial status model can start with To Do, In Progress, Done until clarified.
- ASM-004: Search and filter apply to core task attributes.
