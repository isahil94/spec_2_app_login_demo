# Epics

- EPIC-001: User Access and Identity
- EPIC-002: Task Lifecycle Management
- EPIC-003: Team Coordination and Visibility
