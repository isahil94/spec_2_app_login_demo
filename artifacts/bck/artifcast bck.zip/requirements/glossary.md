# Glossary

- Task: A unit of work tracked by the team.
- Assignee: The accountable owner of a task.
- Dashboard: A consolidated view of work progress.
- Status: The current stage of a task in its lifecycle.
- Filter: Business criteria used to narrow visible tasks.
