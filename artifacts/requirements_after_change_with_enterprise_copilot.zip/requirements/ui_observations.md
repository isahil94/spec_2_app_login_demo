# UI Observations Template

## Purpose
Capture observations from a provided Figma reference without redesigning the experience.

Automatically consume Figma URL from specification.md if present. If absent, continue normally without warnings.

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03
- Status: Draft
- Workflow ID: task-management-ba
- Figma Reference: https://www.figma.com/make/YnxUzBz6USzrnokLtV4Jd0/Task-Management-System-Screens?t=1gWarwbU89pAMBkw-1

## Figma Design Intake
- Design Extraction Status: URL only
- Typography: Visual hierarchy implies multi-level heading/body scale with emphasis for KPI and action labels.
- Spacing: Consistent card/list spacing, form group spacing, and responsive gutters across auth and workspace screens.
- Color Tokens: Distinct semantic colors for status, priority, alerts, and success/error feedback.
- Iconography: Icon usage supports navigation, task status, actions, and notifications with state clarity.
- Component States: Default, hover, focus, active, disabled, loading, empty, error, success are expected for interactive elements.
- Screen Coverage: Login, Register, Dashboard, Task List, Task Details, Create Task, Edit Task, Profile, Settings.
- Interaction Notes: Task actions and filters are primary interactions; auth/profile/settings use explicit validation feedback.
- Responsive Notes: Navigation and content sections should adapt from wide multi-pane to stacked mobile layout.
- Accessibility Notes: Focus visibility, readable contrast, and keyboard reachability required for all primary workflows.
- Missing Design Details: Explicit pagination behavior and notification center edge-state details require confirmation.

## Screen Contracts
- Screen Name: Login
- Purpose: Authenticate existing users.
- Business Goal: Secure workspace entry.
- Navigation: Public -> Submit credentials -> Dashboard
- User Actions: Enter credentials, choose remember me, request password reset, navigate to register.
- Required Fields: Email, Password
- Validation Expectations: Invalid format/credentials show field and form-level feedback.
- Permission Visibility: Visible to unauthenticated users only.
- Empty State: Initial empty form state.
- Success State: Redirect to Dashboard with authenticated context.
- Error State: Invalid credentials or dependency unavailable messages.
- Accessibility Expectations: Keyboard tab order and visible focus for all controls.
- Responsive Expectations: Single-column form on small screens with preserved action visibility.
- Visual Detail Notes: Auth card-centric layout with primary action emphasis.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Protected routes redirect to Login.

- Screen Name: Register
- Purpose: Create new user account.
- Business Goal: Controlled onboarding.
- Navigation: Public -> Submit registration -> Login or Dashboard
- User Actions: Enter identity fields, submit, move to login.
- Required Fields: Email, Password, confirmation where applicable
- Validation Expectations: Duplicate email and password policy feedback.
- Permission Visibility: Visible to unauthenticated users only.
- Empty State: Blank registration form.
- Success State: Account created confirmation.
- Error State: Validation or service-unavailable message.
- Accessibility Expectations: Labels and validation messages are perceivable and keyboard reachable.
- Responsive Expectations: Form scales to mobile without hidden required fields.
- Visual Detail Notes: Mirrored auth pattern with onboarding-specific actions.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Protected routes redirect to Login.

- Screen Name: Dashboard
- Purpose: Show operational snapshot.
- Business Goal: Fast situational awareness.
- Navigation: Login -> Dashboard -> Task List/Task Details/Profile/Settings
- User Actions: Review KPIs, open task/report sections.
- Required Fields: None for viewing; filters where present.
- Validation Expectations: Role-scoped data presentation only.
- Permission Visibility: Authenticated users; report areas role-dependent.
- Empty State: No tasks/activity panel with guidance.
- Success State: KPI cards, recent activity, upcoming deadlines visible.
- Error State: Partial data unavailable panel.
- Accessibility Expectations: KPI and chart/text alternatives remain readable and navigable.
- Responsive Expectations: KPI cards wrap and sections stack on smaller screens.
- Visual Detail Notes: Card-based hierarchy with status emphasis.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Redirect to Login.

- Screen Name: Task List
- Purpose: Discover and manage tasks at scale.
- Business Goal: Rapid retrieval and triage.
- Navigation: Dashboard -> Task List -> Task Details/Create/Edit
- User Actions: Search, filter, sort, bulk actions, open task.
- Required Fields: Search/filters optional; action targets required.
- Validation Expectations: Allowed criteria and role-limited actions.
- Permission Visibility: Task actions vary by role and ownership.
- Empty State: No tasks and no-results states are distinct.
- Success State: Filtered/sorted list with accurate counts.
- Error State: Search or bulk dependency unavailable state.
- Accessibility Expectations: Filter controls and row actions keyboard operable.
- Responsive Expectations: List condenses with preserved action access.
- Visual Detail Notes: Data grid/list with action toolbar.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Redirect to Login.

- Screen Name: Task Details
- Purpose: Full context and collaboration for one task.
- Business Goal: Accurate execution and coordination.
- Navigation: Task List -> Task Details -> Edit Task
- User Actions: Review fields/history, comment, attach, transition status.
- Required Fields: Action-specific required inputs (comment text, valid status).
- Validation Expectations: Transition and edit constraints enforced.
- Permission Visibility: Edit/lifecycle controls role and state dependent.
- Empty State: Missing collaboration history state.
- Success State: Updated details and timeline shown.
- Error State: Update denied/unavailable states shown.
- Accessibility Expectations: Timeline and controls support assistive navigation.
- Responsive Expectations: Detail and activity sections stack cleanly.
- Visual Detail Notes: Primary task metadata plus secondary collaboration stream.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Redirect to Login.

- Screen Name: Create Task
- Purpose: Capture new work items.
- Business Goal: Structured task intake.
- Navigation: Task List/Dashboard -> Create Task -> Task Details
- User Actions: Enter required fields and submit.
- Required Fields: Title, Status, Priority, Due Date
- Validation Expectations: Required field and due-date checks.
- Permission Visibility: Visible only to roles with create permission.
- Empty State: Initial form state.
- Success State: Task created confirmation and redirect.
- Error State: Field errors or save-unavailable state.
- Accessibility Expectations: Form labels and error announcements are perceivable.
- Responsive Expectations: Inputs stack with intact submission controls.
- Visual Detail Notes: Form-centric layout with primary submit action.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Redirect to Login.

- Screen Name: Edit Task
- Purpose: Update existing task attributes.
- Business Goal: Controlled lifecycle progression.
- Navigation: Task Details -> Edit Task -> Task Details
- User Actions: Modify allowed fields, submit/cancel.
- Required Fields: Same required core fields as create where edited.
- Validation Expectations: Completed-task and status-transition restrictions.
- Permission Visibility: Visibility based on role, ownership, and task state.
- Empty State: N/A
- Success State: Updated task values displayed.
- Error State: Validation, authorization, or dependency-unavailable state.
- Accessibility Expectations: Keyboard and screen-reader compatibility for all form controls.
- Responsive Expectations: Edit controls remain visible and usable on narrow screens.
- Visual Detail Notes: Edit variant of task form with context metadata.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Redirect to Login.

- Screen Name: Profile
- Purpose: Manage user account details.
- Business Goal: Maintain accurate personal account data.
- Navigation: Dashboard -> Profile
- User Actions: View/update profile, avatar, password.
- Required Fields: Email and password rules when changed.
- Validation Expectations: Field validation for contact and password updates.
- Permission Visibility: User can modify own profile only.
- Empty State: N/A
- Success State: Profile update confirmation.
- Error State: Validation or save-unavailable state.
- Accessibility Expectations: All profile controls reachable without pointer.
- Responsive Expectations: Profile sections stack and remain readable.
- Visual Detail Notes: Account summary plus editable sections.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Redirect to Login.

- Screen Name: Settings
- Purpose: Manage preferences and admin configuration.
- Business Goal: Tailor user experience and governance controls.
- Navigation: Dashboard/Profile -> Settings
- User Actions: Update personal preferences; admin config actions where authorized.
- Required Fields: Preference values where applicable.
- Validation Expectations: Allowed value sets and role-gated admin controls.
- Permission Visibility: Personal settings for all authenticated users; admin sections for administrators.
- Empty State: N/A
- Success State: Preferences/config updates confirmed.
- Error State: Validation, authorization, or dependency-unavailable state.
- Accessibility Expectations: Grouped controls with clear labels and focus behavior.
- Responsive Expectations: Preference groups collapse into vertical sections.
- Visual Detail Notes: Sectioned settings with role-conditional panels.
- Default Route (mandatory): Login
- Unauthenticated Access Behavior (mandatory): Redirect to Login.

## OpenLog References
- Raise only necessary UI questions in openlog.md.

## Rules
- Describe business behavior only.
- Do not prescribe implementation.
- Keep this artifact focused on the user experience, navigation, and screen-level behavior; do not duplicate the detailed element inventory captured in screen-elements.md.