# API Contracts

## Metadata
- Version: 1.0.0
- Author: Solution Architect Agent
- Date: 2026-07-01
- Status: Draft
- API ID: API-TMS-001
- Service: Task Management Service
- Traceability: REQ-001 to REQ-010, US-001 to US-006, ARCH-TMS-001

## API Overview
Contracts cover authentication, dashboard retrieval, task lifecycle commands, assignment/status updates, and task search/filter. All task endpoints require authenticated session context.

## Endpoints
| Method | Path | Purpose |
|---|---|---|
| POST | /api/v1/auth/register | Register new user account |
| POST | /api/v1/auth/login | Authenticate user and create session |
| POST | /api/v1/auth/logout | Invalidate current session |
| GET | /api/v1/dashboard | Retrieve task summary metrics and recent tasks |
| POST | /api/v1/tasks | Create task |
| GET | /api/v1/tasks | List tasks with optional query/filter |
| GET | /api/v1/tasks/{task_id} | Retrieve task detail |
| PATCH | /api/v1/tasks/{task_id} | Update editable task fields |
| DELETE | /api/v1/tasks/{task_id} | Delete task |
| PATCH | /api/v1/tasks/{task_id}/assignment | Assign or reassign task owner |
| PATCH | /api/v1/tasks/{task_id}/status | Update task status |

## Request Model
- RegisterRequest | email:string required, password:string required, display_name:string required
- LoginRequest | email:string required, password:string required
- CreateTaskRequest | title:string required, description:string optional, status:enum required, assignee_id:string optional
- UpdateTaskRequest | title:string optional, description:string optional, assignee_id:string optional, status:enum optional
- TaskQueryRequest (query params) | q:string optional, status:enum optional, assignee_id:string optional, page:int optional, page_size:int optional

## Response Model
- 200/201 | Success envelope with resource payload and correlation_id
- 204 | Successful delete with empty body
- 400 | Validation error envelope
- 401 | Authentication required
- 403 | Authorization failure
- 404 | Resource not found
- 409 | Conflict (duplicate identity or state conflict)

## Error Model
- AUTH-001 | Invalid credentials | Prompt user to retry login
- AUTH-002 | Session expired | Redirect to login
- TASK-001 | Invalid task status transition | Show allowed status values
- TASK-002 | Unauthorized task mutation | Display permission error
- QUERY-001 | Invalid filter field/value | Return filter guidance

## Authentication and Authorization
- Session-based authentication required for dashboard and all task endpoints.
- Authorization policy baseline: users can mutate tasks they own or are authorized to manage.

## Versioning and Compatibility
- Initial version: v1.
- Additive fields are backward compatible.
- Breaking changes require `/api/v2` namespace and migration notes.

## Validation Rules
- Task title is required and length-bounded.
- Task status must be one of planned, active, completed.
- Assignee must reference an existing active user.
- Query parameter limits protect performance boundaries.

## Dependencies
- User/session persistence contracts.
- Task repository and indexed query strategy.
- Audit event sink for critical mutations.

## Open Questions
### OQ-API-001
- Question: Should dashboard include pagination or only aggregate + recent N tasks in v1?
- Blocking: No

### Open Question Summary
- Total Questions: 1
- Blocking Questions: 0
- Approval Requests Required: No
- Workflow Status: READY
- Next Agent: backend_developer

## Approval
- Prepared By: Solution Architect Agent
- Reviewed By: Pending
- Approved By: Pending
