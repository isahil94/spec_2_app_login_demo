# Personas

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03

### Persona Name: Administrator
- Description: System operator managing users, teams, and global configuration.
- Business Goals: Maintain org structure, ensure security and reporting availability.
- Responsibilities: Manage users, assign roles, archive/restore tasks, view reports.
- Pain Points: Ensuring data integrity and respecting access controls.
- Permissions: Full system management, delete/archive, user disable/reset.
- Primary Screens: Admin user management, Reports, Settings

### Persona Name: Team Lead
- Description: Leads a team and assigns/reviews tasks.
- Business Goals: Ensure team workload balance and timely delivery.
- Responsibilities: Create projects, assign tasks, review completed work.
- Pain Points: Identifying overdue items and resource constraints.
- Permissions: Create and edit team tasks, view reports for their teams.
- Primary Screens: Dashboard, Task List, Task Details, Reports

### Persona Name: Team Member
- Description: Contributor who executes assigned tasks.
- Business Goals: Complete assigned work and track personal tasks.
- Responsibilities: Update task progress, comment, upload attachments.
- Pain Points: Finding assigned tasks and tracking priorities.
- Permissions: Create personal tasks, edit owned tasks, comment.
- Primary Screens: Task List, Task Details, Profile
