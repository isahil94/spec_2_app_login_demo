# Acceptance Criteria

## AC Mapping

- Stories Covered: US-001 to US-010
- Format Standard: Given / When / Then
- Source of Truth: This file is the only acceptance criteria artifact for BA stage

## US-001 Registration

- AC-001.1: Given a new user is on registration, when all required fields are valid and submitted, then the account is created.
- AC-001.2: Given a registration attempt, when required fields are missing, then the user is informed which fields must be completed.
- AC-001.3: Given an existing account identifier, when registration is submitted with duplicate identity information, then account creation is prevented with clear feedback.

## US-002 Login

- AC-002.1: Given a registered user, when valid credentials are submitted, then the user is authenticated and redirected to dashboard.
- AC-002.2: Given an authentication attempt, when credentials are invalid, then access is denied and an error message is shown.
- AC-002.3: Given repeated invalid attempts, when threshold rules apply, then the user receives guidance for secure recovery.

## US-003 Dashboard

- AC-003.1: Given an authenticated user, when dashboard loads, then the user sees summary indicators for relevant tasks.
- AC-003.2: Given no available tasks, when dashboard loads, then an empty state with guidance is shown.
- AC-003.3: Given task updates occur, when dashboard is refreshed, then displayed summary values reflect latest authorized data.

## US-004 Create Task

- AC-004.1: Given task creation is initiated, when required details are provided and submitted, then a new task is created.
- AC-004.2: Given task submission, when title or owner is missing, then the task is not created and validation is shown.
- AC-004.3: Given task creation succeeds, when user returns to task list, then the new task is visible in appropriate results.

## US-005 Edit Task

- AC-005.1: Given an editable task, when permitted fields are changed and saved, then the task reflects updates.
- AC-005.2: Given a user without edit authority, when edit is attempted, then changes are blocked.
- AC-005.3: Given invalid updated values, when save is attempted, then validation prevents update.

## US-006 Delete Task

- AC-006.1: Given a deletable task, when authorized user confirms deletion, then the task is removed from active views.
- AC-006.2: Given deletion confirmation dialog, when user cancels, then task remains unchanged.
- AC-006.3: Given unauthorized user, when delete is attempted, then deletion is blocked.

## US-007 Assign Task

- AC-007.1: Given a task exists, when a valid team member is selected as assignee, then the assignment is updated.
- AC-007.2: Given reassignment is performed, when change is saved, then new ownership is visible in task views.
- AC-007.3: Given an invalid assignee choice, when assignment is submitted, then assignment is rejected with feedback.

## US-008 Track Status

- AC-008.1: Given a valid task, when status is changed using an allowed transition, then new status is saved.
- AC-008.2: Given a disallowed status transition, when update is attempted, then change is prevented with policy feedback.
- AC-008.3: Given status changes are saved, when dashboard and task list are viewed, then the same status is shown consistently.

## US-009 Search Tasks

- AC-009.1: Given user enters relevant keywords, when search runs, then matching tasks are shown.
- AC-009.2: Given no matching tasks, when search runs, then a no-results state is presented.
- AC-009.3: Given restricted tasks exist, when search runs, then only authorized tasks are shown.

## US-010 Filter Tasks

- AC-010.1: Given filter controls are available, when user applies status or assignee filters, then result set updates to matches.
- AC-010.2: Given active filters, when user clears filters, then the default task set is restored.
- AC-010.3: Given a filter combination with no matches, when filters are applied, then clear no-results guidance is shown.
