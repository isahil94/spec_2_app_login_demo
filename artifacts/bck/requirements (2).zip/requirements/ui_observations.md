# UI Observations

## Metadata

- Version: 1.0.0
- Author: Business Analyst Agent
- Date: 2026-07-01
- Status: Draft
- Workflow ID: WF-20260701-001
- Figma Reference: https://www.figma.com/make/YnxUzBz6USzrnokLtV4Jd0/Task-Management-System-Screens?t=1gWarwbU89pAMBkw-1

> Figma URL auto-detected from `specification.md`. Preserved without modification.

---

## Detected Screens

| Screen ID | Name | Purpose | Notes |
|---|---|---|---|
| UI-001 | Registration Screen | New user account creation | Email + Password form; link to login |
| UI-002 | Login Screen | Authenticated access entry point | Email + Password form; link to registration |
| UI-003 | Dashboard Screen | Summary view of tasks and recent activity | Status summary cards + activity feed |
| UI-004 | Task List Screen | Browse and manage all tasks | Tabular/card list with search bar and filter panel |
| UI-005 | Task Creation Screen | Create a new task | Form: title, description, due date, priority, assignee |
| UI-006 | Task Detail Screen | View full task information | All fields, edit/delete actions, status selector |
| UI-007 | Task Edit Screen | Modify an existing task | Same form as Task Creation with pre-populated values |

---

## Navigation Flow

```
[Registration] ←→ [Login]
                      ↓
                [Dashboard]
                      ↓
              [Task List Screen]
                  ↓         ↓
        [Task Creation]  [Task Detail]
                              ↓
                         [Task Edit]
```

- Login is the primary entry point for returning users.
- Registration is accessible from the Login screen.
- Dashboard is the post-login landing page.
- Task List is reachable from the Dashboard.
- Task Creation is accessible from Task List (primary CTA).
- Task Detail is accessible from any task row/card in the Task List.
- Task Edit is accessible from Task Detail.

---

## UI Components

| Component | Screen(s) | Behavior |
|---|---|---|
| Registration Form | UI-001 | Email, password inputs with inline validation; submit button |
| Login Form | UI-002 | Email, password inputs; submit button; error message area |
| Status Summary Cards | UI-003 | Cards showing count per status (To Do, In Progress, Done) |
| Activity Feed | UI-003 | Chronological list of recent task events |
| Task List / Table | UI-004 | Rows/cards per task with title, assignee, status, priority, due date |
| Search Bar | UI-004 | Keyword input; triggers filtered list |
| Filter Panel | UI-004 | Dropdowns/checkboxes for status, assignee, priority, due date range |
| Task Creation Form | UI-005 | Title (required), description, due date picker, priority selector, assignee picker |
| Task Detail View | UI-006 | Full read-only task data; edit and delete action buttons (conditional on permissions) |
| Status Selector | UI-006 | Dropdown to transition task status |
| Task Edit Form | UI-007 | Pre-populated form; same fields as creation form |
| Navigation Header | All authenticated screens | Logo, navigation links (Dashboard, Tasks), user menu (logout) |
| Confirmation Dialog | UI-006 | Modal confirming destructive actions (e.g., delete task) |
| Empty State | UI-004 | Message and CTA when no tasks are present or search/filter yields no results |
| Notification Indicator | Navigation Header | In-app notification badge (for assignment notifications) |

---

## Accessibility Observations

| Observation | Impact | Recommendation |
|---|---|---|
| All form inputs must have associated labels | Screen readers require labels for input identification | Ensure `<label for>` or `aria-label` on all inputs |
| Error messages must be programmatically associated with inputs | Assistive technology won't announce errors without association | Use `aria-describedby` linking inputs to error text |
| Keyboard navigation must cover all interactive elements | Keyboard-only users cannot use features without focus management | Ensure logical tab order and visible focus indicators |
| Confirmation dialogs must trap focus | Users can navigate outside open dialogs without closing them | Modal dialogs must implement focus trap |
| Status colour indicators must not rely on colour alone | Users with colour blindness cannot distinguish status by colour | Add text labels alongside status colour chips |
| CTAs and buttons must have descriptive accessible names | Icon-only buttons are not descriptive for screen readers | Add `aria-label` to icon-only buttons |

---

## Missing Elements

| Element or Behavior Gap | Affected Screen(s) | Notes |
|---|---|---|
| Password strength indicator | UI-001 Registration | Specification states password complexity required; Figma may not show indicator; recommended for UX |
| Session timeout / auto-logout behaviour | All authenticated screens | Not visible in Figma; spec does not address; raise as open question |
| Notification delivery UI (in-app vs email) | Navigation Header, UI-003 | Specification implies notification on assignment (FR-011); delivery channel not defined |
| Pagination or infinite scroll for large task lists | UI-004 Task List | Not specified; essential for usability at scale; raise as open question |
| Empty state for Dashboard when no tasks exist | UI-003 Dashboard | Not addressed in specification; needed for new user experience |
| Error pages (404, 500) | All screens | Not in specification or Figma; required for production quality |

---

## Design Consistency

| Finding | Notes |
|---|---|
| Design system alignment | Figma should define a consistent colour palette, typography scale, and component library; these must be extracted and applied uniformly |
| Responsive breakpoints | Specification states "responsive"; Figma must include mobile and tablet breakpoints for implementation guidance |
| Status colour coding | Status values (To Do, In Progress, Done) should use consistent colour coding across all screens where status appears |
| Form layout consistency | Registration, Login, Task Creation, and Task Edit forms should share a consistent layout pattern |
| Button hierarchy | Primary, secondary, and destructive actions should follow a consistent visual hierarchy across all screens |

---

## Recommendations

| Recommendation | Priority | Rationale |
|---|---|---|
| Extract design tokens (colours, typography, spacing) from Figma before frontend development begins | High | Ensures consistent implementation and reduces rework |
| Define responsive breakpoints in Figma (mobile ≥ 320px, tablet ≥ 768px, desktop ≥ 1280px) | High | Specification requires responsiveness; breakpoints must be explicit |
| Add empty-state designs for Task List, Dashboard, and Search/Filter | Medium | Prevents undefined UI states in implementation |
| Specify notification delivery mechanism (in-app vs email) before Backend development | High | FR-011 is a Should Have; delivery method affects Backend architecture |
| Confirm session timeout behaviour and design logout / re-authentication flow | Medium | Security and UX requirement; not addressed in current specification |
| Validate Figma screens against all 13 user stories to identify missing screens | High | Ensures UI coverage for all stories before UI/UX Developer begins |

---

## OpenLog References

- Notification delivery channel: raise as OQ-002 in `openlog.md`
- Session timeout / auto-logout behaviour: raise as OQ-003 in `openlog.md`
- Pagination strategy for large task lists: raise as OQ-004 in `openlog.md`
