# Component Specification

## Scope
Component contracts for UI-001 to UI-005 screens aligned to API resources in artifacts/architecture/api-contracts.md.

## Components
- AuthForm: collects credentials and registration fields, emits submit and validation events.
- TaskList: renders task collection, empty states, and loading skeletons.
- TaskCard: shows summary data, status badge, assignee, and quick actions.
- TaskForm: create/edit task payloads mapped to CreateTaskRequest and UpdateTaskRequest.
- AssignmentControl: updates assignee through task assignment endpoint.
- StatusControl: updates status using planned, active, completed taxonomy.

## Data Dependencies
- Dashboard metrics and recent tasks from GET /api/v1/dashboard.
- Task queries from GET /api/v1/tasks with q, status, and assignee parameters.
- Task mutations from POST/PATCH/DELETE task endpoints.

## Validation Mapping
- Title required and length-bounded.
- Status constrained to planned, active, completed.
- Assignee must reference selectable active user.

## Error Handling
- Surface AUTH-002 as session-expired redirect to login.
- Surface QUERY-001 with actionable filter guidance.
- Surface TASK-002 as permission-restricted messaging.
