# Acceptance Criteria

## US-001 Register Account
- AC-001.1: Given a guest user, when valid registration details are submitted, then an account is created and the user can proceed to login.
- AC-001.2: Given missing required registration fields, when submit is attempted, then validation messages are shown and no account is created.

## US-002 Login
- AC-002.1: Given valid credentials, when login is submitted, then the user is authenticated and redirected to the dashboard.
- AC-002.2: Given invalid credentials, when login is submitted, then access is denied and a clear error is displayed.

## US-003 Dashboard Summary
- AC-003.1: Given an authenticated user, when dashboard loads, then task counts by status are displayed.
- AC-003.2: Given no tasks, when dashboard loads, then an empty state is shown.

## US-004 Create Task
- AC-004.1: Given valid required fields, when create is submitted, then task is saved and appears in task list.
- AC-004.2: Given missing required fields, when create is submitted, then task is not saved and validation is shown.

## US-005 Edit Task
- AC-005.1: Given an existing task, when updates are submitted with valid data, then changes persist.
- AC-005.2: Given invalid update data, when submit is attempted, then changes are rejected with validation feedback.

## US-006 Delete Task
- AC-006.1: Given an existing task, when delete is confirmed, then task is removed from active listing.
- AC-006.2: Given delete cancellation, when user cancels, then task remains unchanged.

## US-007 Assign Task
- AC-007.1: Given a valid team member, when assignment is saved, then task shows that assignee.
- AC-007.2: Given an invalid assignee reference, when assignment is submitted, then save is rejected with error.

## US-008 Update Status
- AC-008.1: Given an existing task, when status changes to a valid value, then dashboard and list reflect updated status.
- AC-008.2: Given an unsupported status value, when submit is attempted, then update is rejected.

## US-009 Search Tasks
- AC-009.1: Given a search term, when search is applied, then only matching tasks are shown.
- AC-009.2: Given no matches, when search is applied, then no-results state is displayed.

## US-010 Filter Tasks by Status
- AC-010.1: Given a status filter, when filter is applied, then only tasks in that status are shown.
- AC-010.2: Given search and filter applied together, when view updates, then results satisfy both conditions.
