# Features

## Feature 1: Authentication
- User registration
- Login and logout
- Secure access control

## Feature 2: Dashboard
- Overview of tasks and workload
- Task status visibility

## Feature 3: Task Management
- Create, edit, delete tasks
- Task assignment and status updates

## Feature 4: Search and Filtering
- Search by text
- Filter by status or assignee

## Feature 5: Responsive UI
- Desktop and mobile-friendly layout
- Consistency with Figma design direction
