# Interaction Flow

## Primary Flow
1. User opens registration or login screen.
2. Authentication succeeds and routes user to dashboard.
3. User creates or updates tasks from task form.
4. Dashboard refreshes with latest task state.

## Secondary Flows
1. User filters tasks by status/assignee and optional search text.
2. User opens task detail to assign owner and change status.
3. User receives validation feedback for invalid form or filter input.

## State Transitions
- planned -> active -> completed
- active -> planned (allowed rollback if policy permits)
- completed -> active (reopen by authorized user)

## Failure Paths
- Unauthorized mutation: show permission notice and preserve current view.
- Invalid status transition: show allowed transition guidance.
- Empty results: show no-match state with clear reset action.
