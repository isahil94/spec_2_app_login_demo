# Business Rules

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-02
- Status: Draft
- Workflow ID: task-management-ba

## Business Rules

### BR-001 — Single Ownership
- Rule Name: Single Ownership
- Description: Every task must have one owner and at most one assignee.
- Business Justification: Ownership and responsibility must be clear.
- Applies To: Tasks
- Validation: Task creation and updates must include a valid owner and optional assignee.
- Exception: Administrators may reassign ownership when needed.
- Priority: Critical
- Related Stories: US-002, US-003, US-004

---

### BR-002 — Permanent Deletion Restriction
- Rule Name: Permanent Deletion Restriction
- Description: Only administrators may permanently delete tasks.
- Business Justification: Protects against accidental loss of critical work.
- Applies To: Task deletion
- Validation: Permission checks must enforce administrative authority.
- Exception: Standard users may archive their own tasks.
- Priority: High
- Related Stories: US-002, US-005

---

### BR-003 — Archive Access
- Rule Name: Archive Access
- Description: Standard users may archive their own tasks.
- Business Justification: Supports personal task management while preserving accountability.
- Applies To: Task archive actions
- Validation: Archive action must be limited to the appropriate task owner or permitted role.
- Exception: Administrators may archive any task.
- Priority: High
- Related Stories: US-002

---

### BR-004 — Archived Task Read-only
- Rule Name: Archived Task Read-only
- Description: Archived tasks remain searchable but become read-only.
- Business Justification: Preserves historical visibility while preventing unintended changes.
- Applies To: Archived tasks
- Validation: Editing actions must be blocked for archived tasks.
- Exception: Administrators may restore or review archived tasks.
- Priority: High
- Related Stories: US-002

---

### BR-005 — Dashboard Scope
- Rule Name: Dashboard Scope
- Description: Dashboard metrics must reflect the user’s authorized scope and current task state.
- Business Justification: Supports accurate oversight and planning.
- Applies To: Dashboard data
- Validation: Data must be scoped to the current user’s role and team context.
- Exception: Administrators may view broader scope.
- Priority: High
- Related Stories: US-007

---

### BR-006 — Status Lifecycle
- Rule Name: Status Lifecycle
- Description: Task status must follow the allowed lifecycle: Todo → In Progress → Review → Completed, with Review ↔ In Progress and Blocked → In Progress allowed.
- Business Justification: Supports predictable workflow progression.
- Applies To: Task status updates
- Validation: Only supported transitions are permitted.
- Exception: Administrators may override in exceptional cases.
- Priority: Critical
- Related Stories: US-002

---

### BR-007 — Completed Task Editing
- Rule Name: Completed Task Editing
- Description: Completed tasks cannot be edited except by administrators.
- Business Justification: Protects completed work from unintended changes.
- Applies To: Completed tasks
- Validation: Edit actions must be blocked for standard users.
- Exception: Administrators retain edit authority.
- Priority: High
- Related Stories: US-002

---

### BR-008 — Immutable History
- Rule Name: Immutable History
- Description: Task history must be preserved and auditable.
- Business Justification: Supports accountability and traceability.
- Applies To: Task updates and lifecycle events
- Validation: Each change must create an auditable history entry.
- Exception: History entries are immutable.
- Priority: High
- Related Stories: US-002, US-003
