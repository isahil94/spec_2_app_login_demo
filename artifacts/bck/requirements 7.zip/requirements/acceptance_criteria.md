# Acceptance Criteria

## Metadata
- Version: 1.0.0
- Author: Business Analyst Agent
- Date: 2026-07-01
- Status: Draft
- Artifact ID: AC-SET-001
- Traceability: US-001..US-006, REQ-001..REQ-020

## Acceptance Criteria by User Story

### US-001 Authentication
- AC-001: Given a new user with valid required fields, when registration is submitted, then an account is created successfully.
- AC-002: Given a duplicate email, when registration is submitted, then the system rejects submission with clear duplicate-identity feedback.
- AC-003: Given valid credentials, when login is submitted, then the user is authenticated and redirected to dashboard.
- AC-004: Given invalid credentials, when login is submitted, then access is denied with clear guidance and no protected data exposure.
- AC-005: Given an authenticated session, when logout is requested, then the session ends and protected pages require re-authentication.

### US-002 Dashboard
- AC-006: Given an authenticated user, when dashboard loads, then task summary counters are displayed and consistent with visible tasks.
- AC-007: Given zero visible tasks, when dashboard loads, then an empty state with clear next-action guidance is shown.
- AC-008: Given recent task updates, when dashboard refreshes, then status indicators reflect latest known values.
- AC-009: Given user role visibility constraints, when dashboard loads, then only permitted task data is shown.

### US-003 Task Lifecycle Management
- AC-010: Given required task fields are valid, when create is submitted, then a new task is saved and visible in list/dashboard.
- AC-011: Given missing required fields, when create or edit is submitted, then save is blocked and field-level validation is shown.
- AC-012: Given a permitted user and existing task, when edit is submitted with valid values, then updates are persisted and reflected across views.
- AC-013: Given a user without delete permission, when delete is attempted, then deletion is blocked with authorization feedback.
- AC-014: Given a permitted user, when delete is confirmed, then task is removed from active views according to policy.

### US-004 Assignment
- AC-015: Given an eligible assignee, when assignment is submitted by authorized user, then task owner is updated.
- AC-016: Given an ineligible assignee, when assignment is submitted, then update is rejected with clear reason.
- AC-017: Given successful assignment, when update completes, then assignee receives visible assignment notification.
- AC-018: Given assignment update, when task is viewed, then assignment details are consistent across task list/detail.

### US-005 Status Tracking
- AC-019: Given an allowed status transition, when authorized user updates status, then new status is persisted and visible across screens.
- AC-020: Given a disallowed status transition, when update is attempted, then transition is rejected with clear validation message.
- AC-021: Given status changes, when dashboard loads, then status counters reflect updated distribution.
- AC-022: Given unauthorized user, when attempting status change, then action is blocked and state remains unchanged.

### US-006 Search and Filter
- AC-023: Given a valid keyword query, when search is applied, then only matching visible tasks are returned.
- AC-024: Given selected filters (status/assignee/priority/due scope), when applied, then results satisfy all selected criteria.
- AC-025: Given query and filters together, when applied, then intersected result set is returned deterministically.
- AC-026: Given no matching tasks, when criteria are applied, then a no-result state with reset option is displayed.
- AC-027: Given visibility constraints, when searching/filtering, then hidden tasks never appear in result sets.

## Coverage Expectations
- Happy path, alternate path, validation, error handling, authorization, and state transition behavior are defined for each story.
- Search, filtering, and no-result behavior are explicitly covered where applicable.
