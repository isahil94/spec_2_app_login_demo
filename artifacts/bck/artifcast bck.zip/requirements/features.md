# Features

- FEAT-001 | Registration
- FEAT-002 | Login and Logout
- FEAT-003 | Dashboard Overview
- FEAT-004 | Task Creation
- FEAT-005 | Task Editing
- FEAT-006 | Task Deletion
- FEAT-007 | Task Assignment
- FEAT-008 | Task Status Tracking
- FEAT-009 | Task Search
- FEAT-010 | Task Filtering
