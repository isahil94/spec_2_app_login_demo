# Business Data Model (Conceptual)

## Conceptual Entities
- User: Person participating in team task workflows.
- Task: Work item tracked from creation to completion.
- Team: Group of users collaborating on tasks.
- Role: Business responsibility profile for access scope.
- Dashboard Summary: Aggregated task progress information.

## Conceptual Relationships
- A Team includes many Users.
- A User may own many Tasks over time.
- A Task has one current accountable User.
- A User performs work under a Role.
- Dashboard Summary reflects Task states across Users and Teams.

## Business Notes
- Entity definitions are conceptual and implementation-neutral.
- Physical schema design is out of scope for this artifact.
