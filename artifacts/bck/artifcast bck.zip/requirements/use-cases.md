# Use Cases

### UC-001 Account Registration
- Primary Actor: New User
- Trigger: User selects registration option.
- Preconditions: Registration is available.
- Main Flow: User submits registration information and receives account confirmation.
- Alternative Flow: Required information is incomplete.
- Postconditions: User account is available for sign-in.
- Business Outcome: New team members can access the platform.

### UC-002 Task Assignment
- Primary Actor: Team Lead
- Trigger: Team Lead assigns a task.
- Preconditions: Task exists and team member is available.
- Main Flow: Team Lead selects assignee and confirms assignment.
- Alternative Flow: No valid assignee available.
- Postconditions: Task has accountable owner.
- Business Outcome: Clear work ownership.

### UC-003 Task Tracking
- Primary Actor: Team Member
- Trigger: Team Member updates or reviews task status.
- Preconditions: Task exists and is visible to actor.
- Main Flow: Team Member changes status and dashboard reflects update.
- Alternative Flow: Status transition not allowed by policy.
- Postconditions: Progress visibility is current.
- Business Outcome: Reliable progress tracking.
