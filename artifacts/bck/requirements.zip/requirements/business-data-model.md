# Business Data Model

## Core Entities
- User
  - id
  - email
  - passwordHash
  - displayName
- Task
  - id
  - title
  - description
  - status
  - createdBy
  - assigneeId
  - createdAt
  - updatedAt

## Relationships
- A user can create many tasks.
- A user can be assigned many tasks.
- Each task belongs to one creator and optionally one assignee.
