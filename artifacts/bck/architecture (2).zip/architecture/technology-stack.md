# Technology Stack

## Metadata
- Version: 1.0.0
- Author: Solution Architect Agent
- Date: 2026-07-01
- Status: Draft
- Workflow ID: WF-20260701-0001
- Stack ID: STACK-TMS-001

## Stack Summary
| Layer | Technology | Rationale |
|---|---|---|
| Backend Runtime | Python 3.14 | Aligns with repository runtime and scripts |
| API Framework | FastAPI | Typed contracts, validation, strong testability |
| Data Validation | Pydantic | Deterministic schema validation for requests/responses |
| Persistence | SQLite (local-first) with SQLAlchemy | Lightweight local execution and clean ORM boundaries |
| Auth | Secure password hashing + session token strategy | Meets secure login and protected route requirements |
| Frontend | HTML/CSS/JS or lightweight component framework | Supports responsive Figma-aligned delivery with minimal overhead |
| Testing | pytest | Existing test standard in repository |
| Observability | Structured logging + metrics hooks | Supports logging/audit/observability NFRs |

## Design Constraints for Stack
- Keep dependencies minimal and deterministic for local execution.
- Prefer typed interfaces and schema-first endpoint definitions.
- Use migration-ready persistence design, even for SQLite-first deployment.

## Required Conventions
- API models and domain models remain separated.
- Secrets are environment-driven; no hardcoded credentials.
- All critical actions must include actor and timestamp in logs.

## Deferred Decisions
- Whether frontend should remain server-rendered or use SPA composition.
- Whether session transport is cookie-based only or dual token strategy.
