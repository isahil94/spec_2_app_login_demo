# Acceptance Criteria

## US-001 Registration
- AC-US001-01
  - Given a new user is on the registration page
  - When they submit all required fields with valid values
  - Then the account is created successfully.
- AC-US001-02
  - Given a new user is on the registration page
  - When required fields are missing or invalid
  - Then registration is blocked and clear validation messages are shown.

## US-002 Login
- AC-US002-01
  - Given a registered user is on the login page
  - When valid credentials are submitted
  - Then access is granted to authenticated areas.
- AC-US002-02
  - Given a registered user is on the login page
  - When invalid credentials are submitted
  - Then access is denied and the user remains unauthenticated.

## US-003 Create and Edit Task
- AC-US003-01
  - Given an authenticated user on task form
  - When valid task data is submitted
  - Then the task is saved and appears in task listings.
- AC-US003-02
  - Given an authenticated user edits an existing task
  - When updates are submitted with valid data
  - Then updated values are persisted and visible.
- AC-US003-03
  - Given an authenticated user on task form
  - When mandatory fields are missing
  - Then save is blocked and validation feedback is displayed.

## US-004 Delete Task
- AC-US004-01
  - Given an authenticated user can manage a task
  - When delete is initiated
  - Then a confirmation step is displayed.
- AC-US004-02
  - Given a delete confirmation is shown
  - When the user confirms
  - Then the task is removed from active task views.
- AC-US004-03
  - Given a delete confirmation is shown
  - When the user cancels
  - Then the task remains unchanged.

## US-005 Status Tracking
- AC-US005-01
  - Given a task exists
  - When an authenticated user selects an allowed status
  - Then the task status is updated successfully.
- AC-US005-02
  - Given task status is updated
  - When user views dashboard and task list
  - Then status is displayed consistently across views.

## US-006 Assignment
- AC-US006-01
  - Given an authenticated user with assignment permission
  - When a task is assigned to an active team member
  - Then the selected assignee is saved.
- AC-US006-02
  - Given an assigned task
  - When task details are displayed
  - Then assignee information is visible.

## US-007 Dashboard
- AC-US007-01
  - Given an authenticated user
  - When the dashboard is opened
  - Then a summary of tasks by status is shown.
- AC-US007-02
  - Given no tasks are available for view
  - When dashboard is opened
  - Then an empty-state experience is displayed.

## US-008 Search and Filter
- AC-US008-01
  - Given an authenticated user on task list
  - When search text is entered
  - Then only matching accessible tasks are displayed.
- AC-US008-02
  - Given an authenticated user on task list
  - When filters by status and assignee are applied
  - Then the task list reflects matching criteria.
- AC-US008-03
  - Given filters are active
  - When filters are cleared
  - Then full accessible task list is restored.

## US-009 Responsive and User-Friendly Experience
- AC-US009-01
  - Given a user accesses the application on desktop and mobile sizes
  - When using core workflows
  - Then interfaces remain readable and usable.
- AC-US009-02
  - Given provided Figma reference exists
  - When UI is implemented
  - Then key layout and interaction intent align with design direction.
