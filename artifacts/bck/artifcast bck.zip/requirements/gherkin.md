# Gherkin Scenarios

Feature: Task Assignment
  Scenario: Assign a task to a team member
    Given a task exists and a team member is available
    When the team lead assigns the task
    Then the task shows the new assignee

Feature: Task Search
  Scenario: Search by keyword
    Given tasks exist in the workspace
    When a user searches with a keyword
    Then matching tasks are returned

Feature: Status Tracking
  Scenario: Update task status
    Given a task is visible to a user
    When the user updates the status
    Then the task status is updated in task views and dashboard summaries
