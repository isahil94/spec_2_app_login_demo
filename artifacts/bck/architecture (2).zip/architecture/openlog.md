# Open Log

Template Version: 4.0.0
Owner Agent: solution_architect
Workflow ID: WF-20260701-0001
Correlation ID: CORR-TMS-20260701-001
Generated: 2026-07-01T16:30:00Z
Last Updated: 2026-07-01T16:30:00Z

## Workflow Status
| Field | Value |
|---|---|
| Workflow ID | WF-20260701-0001 |
| Current Stage | architecture |
| Current State | READY |
| Open Items | 3 |
| Blocking Items | 0 |
| Pending HITL | 0 |
| Next Agent | ui_ux_developer |
| Supervisor Action | Continue |

## Open Question Lifecycle
NEW -> UNDER_REVIEW -> WAITING_FOR_APPROVAL -> APPROVED/REJECTED -> RESOLVED -> CLOSED

## Open Items

### OQ-001
| Field | Value |
|---|---|
| Entry ID | OQ-001 |
| Workflow ID | WF-20260701-0001 |
| Correlation ID | CORR-TMS-20260701-001 |
| Date | 2026-07-01T16:30:00Z |
| Category | Open Question |
| Title | Finalize authorization override scope |
| Question | Should Team Lead role include override permissions for edit/delete on all team tasks in v1? |
| Reason | Requirements specify authorization boundaries but do not define role override policy. |
| Priority | High |
| Impact | Medium |
| Blocking | No |
| Approval Required | No |
| Default Assumption | Owner-based edit/delete permissions with no global override in v1. |
| Owner Agent | solution_architect |
| Target Stage | backend_developer |
| Related Artifact(s) | architecture-design.md, security-architecture.md |
| Related Requirement(s) | REQ-005, REQ-006 |
| Related User Story(ies) | US-004 |
| Potential Risk | Late policy changes could require API authorization contract updates. |
| Status | NEW |
| Resolution | Pending |
| Decision | Pending |
| Decision By | Pending |
| Decision Date | Pending |

#### History
- 2026-07-01T16:30:00Z Created. Status: NEW.

### OQ-002
| Field | Value |
|---|---|
| Entry ID | OQ-002 |
| Workflow ID | WF-20260701-0001 |
| Correlation ID | CORR-TMS-20260701-001 |
| Date | 2026-07-01T16:30:00Z |
| Category | Open Question |
| Title | Finalize minimum filter facets |
| Question | Should v1 filter set include only status and assignee, or also created date and text fields? |
| Reason | Search/filter requirement exists, but minimum standardized facets are not explicitly fixed. |
| Priority | Medium |
| Impact | Medium |
| Blocking | No |
| Approval Required | No |
| Default Assumption | Status and assignee are mandatory; created date is optional extension. |
| Owner Agent | solution_architect |
| Target Stage | ui_ux_developer |
| Related Artifact(s) | api-contracts.md, module-design.md |
| Related Requirement(s) | REQ-009, REQ-010 |
| Related User Story(ies) | US-006 |
| Potential Risk | UI and API divergence if facets are expanded late. |
| Status | NEW |
| Resolution | Pending |
| Decision | Pending |
| Decision By | Pending |
| Decision Date | Pending |

#### History
- 2026-07-01T16:30:00Z Created. Status: NEW.

### OQ-003
| Field | Value |
|---|---|
| Entry ID | OQ-003 |
| Workflow ID | WF-20260701-0001 |
| Correlation ID | CORR-TMS-20260701-001 |
| Date | 2026-07-01T16:30:00Z |
| Category | Open Question |
| Title | Confirm session transport strategy |
| Question | Should v1 session handling be cookie-only, or support both secure cookie and bearer token transport? |
| Reason | Security requirements mandate protected routes but do not define transport mode. |
| Priority | Medium |
| Impact | Low |
| Blocking | No |
| Approval Required | No |
| Default Assumption | Secure HTTP-only cookie session for browser-first workflow. |
| Owner Agent | solution_architect |
| Target Stage | backend_developer |
| Related Artifact(s) | security-architecture.md, api-contracts.md |
| Related Requirement(s) | REQ-002 |
| Related User Story(ies) | US-002 |
| Potential Risk | Changing transport post-implementation affects auth middleware and clients. |
| Status | NEW |
| Resolution | Pending |
| Decision | Pending |
| Decision By | Pending |
| Decision Date | Pending |

#### History
- 2026-07-01T16:30:00Z Created. Status: NEW.

## Append Rules
- Compact the content, never compact the schema.
- Keep field values concise (1-3 lines where appropriate).
- Append-only: never delete existing entries.
- Record every status transition in History.
- Use this as the only governance open-items artifact.
