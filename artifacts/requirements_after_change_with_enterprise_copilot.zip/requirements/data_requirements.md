# Data Requirements Template

## Purpose
Capture business data expectations without defining database schema.

## Metadata
- Version: 1.0
- Author: Business Analyst Agent
- Date: 2026-07-03
- Status: Draft
- Workflow ID: task-management-ba

## Business Entities

### Entity: User
- Business Meaning: Individual identity that accesses and interacts with the task management workspace.
- Owner: Administrator (governance), individual user (profile content)
- Required Attributes: User ID, Email, Role, Account Status, Created Date
- Optional Attributes: Avatar, Contact Information, Language, Time Zone, Notification Preferences
- Relationships: Belongs to zero or more Teams; owns/reports/assignee for Tasks; receives Notifications
- Lifecycle: Invited -> Active -> Disabled -> Deleted (where policy permits)
- Retention: Account and governance history retained per audit expectations
- PII Classification: Sensitive

### Entity: Team
- Business Meaning: Collaborative group responsible for shared task execution.
- Owner: Administrator or Team Lead (as permitted)
- Required Attributes: Team ID, Team Name, Owner, Created Date
- Optional Attributes: Team Description, Team Role Defaults
- Relationships: Has many Team Members; contains many Tasks
- Lifecycle: Created -> Active -> Archived/Inactive
- Retention: Team membership and ownership history retained for governance review
- PII Classification: Internal

### Entity: Team Membership
- Business Meaning: Association of users to teams with role context.
- Owner: Administrator/Team Lead per permissions
- Required Attributes: Membership ID, Team ID, User ID, Team Role, Membership Status
- Optional Attributes: Invitation Timestamp, Join Timestamp
- Relationships: Links User and Team
- Lifecycle: Invited -> Accepted -> Active -> Removed
- Retention: Membership change history retained for audit
- PII Classification: Internal

### Entity: Task
- Business Meaning: Work item tracked through defined status and priority lifecycle.
- Owner: Task Owner (business), Administrator (governance override)
- Required Attributes: Task ID, Title, Status, Priority, Owner, Reporter, Due Date, Created Date, Updated Date, Archived Flag
- Optional Attributes: Description, Assignee, Labels
- Relationships: Linked to User (owner/reporter/assignee), Team, Comments, Attachments, Activity History
- Lifecycle: Todo -> In Progress -> Review -> Completed; Archived and Restored by permission
- Retention: Historical tasks retained with immutable activity history
- PII Classification: Internal

### Entity: Task Comment
- Business Meaning: Collaboration message attached to a task.
- Owner: Comment Author
- Required Attributes: Comment ID, Task ID, Author, Comment Text, Created Date
- Optional Attributes: Mentioned Users
- Relationships: Belongs to Task; references User(s)
- Lifecycle: Created -> Visible in timeline
- Retention: Retained as part of immutable task history
- PII Classification: Internal

### Entity: Task Attachment
- Business Meaning: Supporting file reference associated with a task.
- Owner: Uploader
- Required Attributes: Attachment ID, Task ID, Uploader, Attachment Reference, Created Date
- Optional Attributes: Attachment Description
- Relationships: Belongs to Task; references User
- Lifecycle: Uploaded -> Available in task context
- Retention: Retained according to task retention policy
- PII Classification: Sensitive

### Entity: Activity History
- Business Meaning: Immutable chronological record of task and governance updates.
- Owner: System governance
- Required Attributes: Activity ID, Related Entity ID, Actor, Action Type, Timestamp, Outcome
- Optional Attributes: Context Summary
- Relationships: Linked to Task/User/Team actions
- Lifecycle: Appended only
- Retention: Mandatory retention for audit and compliance review
- PII Classification: Internal

### Entity: Notification
- Business Meaning: User-targeted alert generated from business events.
- Owner: User preference context and system event source
- Required Attributes: Notification ID, Recipient, Trigger Type, Channel Type, Delivery Status, Created Date
- Optional Attributes: Read Status, Related Task
- Relationships: Linked to User and optionally Task
- Lifecycle: Generated -> Delivered/Delayed -> Read/Unread
- Retention: Retained for operational visibility and troubleshooting
- PII Classification: Internal

### Entity: Report
- Business Meaning: Aggregated operational insight for productivity, completion, workload, overdue, and user activity.
- Owner: Authorized report consumer role
- Required Attributes: Report Type, Scope, Period, Generated Date
- Optional Attributes: Applied Filters
- Relationships: Derived from Task, User, Team, Activity data
- Lifecycle: Requested -> Generated -> Viewed
- Retention: Retained according to reporting governance
- PII Classification: Internal

## Notes
- Keep this document business-focused and implementation-agnostic.
- Do not define tables, columns, keys, SQL, or storage design.